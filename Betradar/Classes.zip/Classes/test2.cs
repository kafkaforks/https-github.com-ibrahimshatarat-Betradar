﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.Lcoo;

namespace Betradar.Classes
{
   public class test2:Core
    {
       public test2()
       {
            var tes = new test();
           tes.one = "the first";
            var test = new Text();
           test.ID = 33;
           test.SUPERID = 444554;
            test.Text_language.Language = new Language();
           test.Type = 3;
           tes.two = test;



            ////////////
            /// 
            /// 
            /// 
            /// 
            var param = new NpgsqlParameter("name", NpgsqlDbType.Text);
            param.Value = "Heytham";
            var connectionBuilder = new Npgsql.NpgsqlConnectionStringBuilder();
            connectionBuilder.Host = config.AppSettings.Get("DB_Host");
            connectionBuilder.Port = int.Parse(config.AppSettings.Get("DB_Port"));
            connectionBuilder.Database = config.AppSettings.Get("DB_Database");
            connectionBuilder.Username = config.AppSettings.Get("DB_Username");
            connectionBuilder.Password = config.AppSettings.Get("DB_Password");
            connectionBuilder.Timeout = 20;
            connectionBuilder.CommandTimeout = 20;
            var con = new NpgsqlConnection(connectionBuilder.ConnectionString);
            var objCommand = new NpgsqlCommand("test_insert2", con);
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Add(param);
            objCommand.Connection = con;

            con.MapComposite<test>();

          
            if (objCommand != null)
            {
                for (int i = 0; i < 5000; i++)
                {
                    objCommand.Connection.Open();
                    objCommand.ExecuteNonQuery();
                    objCommand.Connection.Close();
                }
            }

        }
    }
}
