﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.SDK.FeedProviders.LiveScout;

namespace Betradar.Classes.DbInsert
{
    class LiveScout_Lineup_Handle:Core
    {
        public LiveScout_Lineup_Handle(LineupsEventArgs args)
        {
            insertLineups(args);
        }
        public void insertLineups(LineupsEventArgs Lineupentity)
        {
            var entity = Lineupentity.Lineups;
            var queue = new Queue<Globals.Rollback>();
            var common = new Common();
            var command = new NpgsqlCommand(Globals.DB_Functions.InsertLineups.ToDescription());
            try
            {
                if (entity.AdditionalData != null)
                {
                    var ret = common.insertAdditionalData(entity.AdditionalData);
                    if (ret.id != -1)
                    {
                        command.Parameters.AddWithValue("fk_dictionary_additionaldata_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.LiveScoutLineUps, Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_dictionary_additionaldata_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_dictionary_additionaldata_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Managers != null)
                {
                    var ret = common.insertManagers(entity.Managers);
                    if (ret.id != -1)
                    {
                        command.Parameters.AddWithValue("fk_managers_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Managers, Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_managers_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_managers_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.MatchId != null)
                {
                    command.Parameters.AddWithValue("match_id", NpgsqlDbType.Bigint, entity.MatchId);
                }
                else
                {
                    command.Parameters.AddWithValue("match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Players != null)
                {
                    var ret = common.insertPlayers(entity.Players);
                    command.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                var ObjId = common.insert(command);

                if (ObjId == -1)
                {
                    queue.Enqueue(SetRollback(ObjId, Globals.Tables.LiveScoutLineUps, Globals.TransactionTypes.Insert));
                    throw new Exception("Error in Insert Bet Stop");
                }
#if DEBUG
                OutCount += 1;
                Logg.logger.Error("InCount Count = " + InCount + "  ||||| OutCount = " + OutCount);
#endif
            }
            catch (Exception ex)
            {
                common.RollBack(queue.ToList());
                Logg.logger.Fatal(ex.Message);
            }
        }
    }
}
