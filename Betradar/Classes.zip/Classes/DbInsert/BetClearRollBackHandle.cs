﻿using System;
using System.Collections.Generic;
using System.Linq;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;

namespace Betradar.Classes.DbInsert
{
    public class BetClearRollBackHandle : Core
    {

        public BetClearRollBackHandle(BetClearRollbackEventArgs args)
        {
            RunTask(args);
        }

        public void RunTask(BetClearRollbackEventArgs queueElement)
        {
            int maxRetries = 0;
            var common = new Common();
            var queue = new Queue<Globals.Rollback>();
            try
            {
                var entity = queueElement.BetClearRollback;

                //Additional Data 
                var objCommand = new NpgsqlCommand(Globals.DB_Functions.InsertLive.ToDescription());
                objCommand.Parameters.AddWithValue("fk_feed_type_id", NpgsqlDbType.Bigint, Globals.FeedTypes.BetClearRollBack);
                if (entity.AdditionalData != null)
                {
                    var ret = common.insertAdditionalData(entity.AdditionalData);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Dictionaries, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                objCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint, DBNull.Value);
                objCommand.Parameters.AddWithValue("end_time", NpgsqlDbType.Timestamp, DBNull.Value);

                if (entity.EventHeader != null)
                {
                    var ret = common.insertEventHeader(entity);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_event_header_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_event_header_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Event_Header, Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }

                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_event_header_id", NpgsqlDbType.Bigint, DBNull.Value);
                }

                objCommand.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);

                if (entity.IsOutOfBand != null)
                {
                    objCommand.Parameters.AddWithValue("isoutof_band", NpgsqlDbType.Boolean, entity.IsOutOfBand);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("isoutof_band", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Messages != null && entity.Messages.Length > 0)
                {
                    var ret = common.insertMessages(entity.Messages);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Event_Header, Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }

                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    objCommand.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }

                objCommand.Parameters.AddWithValue("fx_odds_id", NpgsqlDbType.Bigint, DBNull.Value);

                objCommand.Parameters.AddWithValue("priority", NpgsqlDbType.Text, DBNull.Value);

                if (entity.ReplyNr != null)
                {
                    objCommand.Parameters.AddWithValue("reply_nr", NpgsqlDbType.Bigint, entity.ReplyNr);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("reply_nr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.ReplyType != null)
                {
                    objCommand.Parameters.AddWithValue("odds_reply_type", NpgsqlDbType.Text, entity.ReplyType.Value);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("odds_reply_type", NpgsqlDbType.Text, DBNull.Value);
                }

                objCommand.Parameters.AddWithValue("server_type", NpgsqlDbType.Integer, DBNull.Value);

                if (entity.ServerVersion != null)
                {
                    objCommand.Parameters.AddWithValue("server_version", NpgsqlDbType.Text, entity.ServerVersion);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("server_version", NpgsqlDbType.Text, DBNull.Value);
                }

                objCommand.Parameters.AddWithValue("start_time", NpgsqlDbType.Timestamp, DBNull.Value);

                if (entity.Status != null)
                {
                    objCommand.Parameters.AddWithValue("odds_status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("odds_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Time != null)
                {
                    objCommand.Parameters.AddWithValue("time", NpgsqlDbType.Bigint, entity.Time);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("time", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Timestamp != null)
                {
                    objCommand.Parameters.AddWithValue("timestamp", NpgsqlDbType.Timestamp, entity.Timestamp);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("timestamp", NpgsqlDbType.Timestamp, DBNull.Value);
                }
                if (entity.VirtualGameId != null)
                {
                    objCommand.Parameters.AddWithValue("virtual_game_id", NpgsqlDbType.Bigint, entity.VirtualGameId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("virtual_game_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                var ObjId = common.insert(objCommand);

                if (ObjId == -1)
                {
                    queue.Enqueue(SetRollback(ObjId, Globals.Tables.Live_Common_Feed, Globals.TransactionTypes.Insert));
                    throw new Exception("Error in Insert Bet Clear RollBack");
                }
#if DEBUG
                OutCount += 1;
                Logg.logger.Error("InCount Count = " + InCount + "  ||||| OutCount = " + OutCount);
#endif
            }
            catch (Exception ex)
            {
                common.RollBack(queue.ToList());
                Logg.logger.Fatal(ex.Message);
            }

        }
    }
}
