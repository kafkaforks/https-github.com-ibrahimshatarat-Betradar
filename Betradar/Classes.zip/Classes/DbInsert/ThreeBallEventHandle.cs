﻿using System;
using System.Collections.Generic;
using System.Linq;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.Lcoo;

namespace Betradar.Classes.DbInsert
{
    public class ThreeBallEventHandle : Core
    {
        public ThreeBallEventHandle(ThreeBallEventArgs args)
        {
            ThreeBallEvent_Queue_WatchQueueMatches(args);
        }
        public void ThreeBallEvent_Queue_WatchQueueMatches(ThreeBallEventArgs queueElement)
        {
            var common = new Common();
            var queue = new Queue<Globals.Rollback>();
            try
            {
                var entity = queueElement.ThreeBallEntity;
                var command = new NpgsqlCommand(Globals.DB_Functions.InsertThreeBall.ToDescription());
                command.Parameters.AddWithValue("fk_feed_type_id", NpgsqlDbType.Bigint, Globals.FeedTypes.ThreeBallEvent);
                if (entity.AdditionalData != null)
                {
                    var ret = common.insertAdditionalData(entity.AdditionalData);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Dictionaries, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Category != null)
                {
                    var ret = common.insertCategory(entity.Category);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_category_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_category_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Category, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_category_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.FeedType.ToString()))
                {
                    command.Parameters.AddWithValue("feed_type", NpgsqlDbType.Text, entity.FeedType.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("feed_type", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Fixture != null)
                {
                    var ret = common.insertFixture(entity.Fixture);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Fixture, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("three_ball_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("three_ball_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.MessageTime != null)
                {
                    command.Parameters.AddWithValue("message_time", NpgsqlDbType.Timestamp, entity.MessageTime);
                }
                else
                {
                    command.Parameters.AddWithValue("message_time", NpgsqlDbType.Timestamp, DBNull.Value);
                }
                if (entity.Odds != null && entity.Odds.Count > 0)
                {
                    var ret = common.insertBets(entity.Odds,entity.Id);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_bet_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_bet_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Bets, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_bet_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Result != null)
                {
                    var ret = common.insertResult(entity.Result);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_result_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_result_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Result, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_result_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Sport != null)
                {
                    var ret = common.insertSport(entity.Sport);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Sports, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Tournament != null)
                {
                    var ret = common.insertTournament(entity.Tournament);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_tournament_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Tournament, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                var ObjId = common.insert(command);

                if (ObjId == -1)
                {
                    queue.Enqueue(SetRollback(ObjId, Globals.Tables.ThreeBall, Globals.TransactionTypes.Insert));
                    throw new Exception("Error in Insert Three Ball Event");
                }
#if DEBUG
                OutCount += 1;
                Logg.logger.Error("InCount Count = " + InCount + "  ||||| OutCount = " + OutCount);
#endif
            }
            catch (Exception ex)
            {
                common.RollBack(queue.ToList());
                Logg.logger.Fatal(ex.Message);
            }
        }
    }

}
