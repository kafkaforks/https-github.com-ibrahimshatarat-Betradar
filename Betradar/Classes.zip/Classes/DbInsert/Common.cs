﻿using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.Common;
using Sportradar.SDK.FeedProviders.Common;
using Sportradar.SDK.FeedProviders.Lcoo;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;
using Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds;
using Sportradar.SDK.FeedProviders.LiveOdds.Outrights;
using Sportradar.SDK.FeedProviders.LiveScout;
using Sportradar.SDK.ProtocolProviders.LiveScout.Server;
using static Betradar.Classes.Globals;
using Attribute = Sportradar.SDK.FeedProviders.LiveScout.Attribute;
using MatchHeader = Sportradar.SDK.FeedProviders.LiveOdds.LiveOdds.MatchHeader;


namespace Betradar.Classes
{
    public class Common : Core
    {
        private NpgsqlConnection con;
        private element entity;

        public Common()
        {

        }



        /// <summary>
        /// Insert corners related to another insertion for grouping 
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertCorners(CornersEntity entity)
        {
            var queue = new Queue<Rollback>();
            try
            {

                ///Insert into the main Corners table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertCorners.ToDescription().ToString());
                if (entity.Doubtful != null)
                {
                    adObjCommand.Parameters.AddWithValue("doubtful", NpgsqlDbType.Boolean, entity.Doubtful);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("doubtful", NpgsqlDbType.Boolean, DBNull.Value);
                }

                adObjCommand.Parameters.AddWithValue("fk_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                var corner_id = insert(adObjCommand);

                if (corner_id > 0)
                {
                    /// Now insert the detailed dictionaries to dictionary table
                    foreach (var corner in entity.Corners)
                    {
                        var cornerObjCommand = new NpgsqlCommand(DB_Functions.InsertCard.ToDescription());

                        if (corner.Count != null)
                        {
                            cornerObjCommand.Parameters.AddWithValue("count", corner.Count);
                        }
                        else
                        {
                            cornerObjCommand.Parameters.AddWithValue("count", NpgsqlDbType.Integer, DBNull.Value);
                        }
                        if (corner.Type != null)
                        {
                            cornerObjCommand.Parameters.AddWithValue("type", corner.Type);
                        }
                        else
                        {
                            cornerObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (corner.Team != null)
                        {
                            cornerObjCommand.Parameters.AddWithValue("fk_team_id", corner.Team);
                        }
                        else
                        {
                            cornerObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        cornerObjCommand.Parameters.AddWithValue("fk_corners_id", NpgsqlDbType.Bigint, corner_id);

                        queue.Enqueue(SetRollback(insert(cornerObjCommand), Tables.Corner, TransactionTypes.Insert));
                    }

                }
                return new ReturnQueueLong(queue, corner_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Selects the enum value
        /// </summary>
        /// <param name="enumMaster"></param>
        /// <param name="enumSlave"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public int selectEnumValue(string enumMaster, string enumSlave)
        {
            var adObjCommand = new NpgsqlCommand(DB_Functions.SelectEnumsByNames.ToDescription());
            adObjCommand.Parameters.AddWithValue("enum_group_name", enumMaster);
            adObjCommand.Parameters.AddWithValue("enum_name", enumSlave);
            var ds = select(adObjCommand);
            var result = -1;
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    result = int.Parse(ds.Tables[0].Rows[0]["select_enum_by_names"].ToString());
                }
            }
            return result;
        }

        /// <summary>
        /// Insert Category 
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertCategory(CategoryEntity entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertCategory.ToDescription());
                if (entity.IsoId != null)
                {
                    adObjCommand.Parameters.AddWithValue("isoid", NpgsqlDbType.Integer, entity.IsoId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("isoid", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.IsoName))
                {
                    adObjCommand.Parameters.AddWithValue("isoname", NpgsqlDbType.Text, entity.IsoName);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("isoname", NpgsqlDbType.Text, DBNull.Value);
                }
                adObjCommand.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (entity.Id != null)
                {
                    adObjCommand.Parameters.AddWithValue("category_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("category_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Texts.Count > 0)
                {
                    var id = insertTexts(entity.Texts);
                    queue.Enqueue(SetRollback(id, Tables.Texts, TransactionTypes.Insert));
                    adObjCommand.Parameters.AddWithValue("fx_text_id", NpgsqlDbType.Bigint, id);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fx_text_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Attribute
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertAttribute(Attribute entity, long? AttributesId)
        {
            var queue = new Queue<Rollback>();
            try
            {
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertPlayerEntity.ToDescription());
                if (entity.Type != null)
                {
                    adObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, entity.Type);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.TypeId != null)
                {
                    adObjCommand.Parameters.AddWithValue("type_id", NpgsqlDbType.Bigint, TransactionTypes.Insert);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("type_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Value != null)
                {
                    adObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, entity.Value);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.ValueId != null)
                {
                    adObjCommand.Parameters.AddWithValue("value_id", NpgsqlDbType.Bigint, entity.ValueId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("value_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                adObjCommand.Parameters.AddWithValue("fk_attributes_id", NpgsqlDbType.Bigint, AttributesId);

                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert List of Attributes
        /// </summary>
        /// <param name="entityList"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertAttributes(List<Attribute> entityList)
        {
            var queue = new Queue<Rollback>();
            try
            {

                ///Insert into the main Attribute table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertAttributes.ToDescription().ToString());

                adObjCommand.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Bigint, false);
                var attributes_id = insert(adObjCommand);
                if (attributes_id > 0)
                {
                    /// Now insert the detailed attributes to player table
                    foreach (var attribute in entityList)
                    {
                        var ret = insertAttribute(attribute, attributes_id);
                        if (ret.id != -1)
                        {
                            queue = CloneRollbackQueue(queue, ret.queue);
                            queue.Enqueue(SetRollback(ret.id, Tables.Attribute, TransactionTypes.Insert));
                        }

                    }
                }
                return new ReturnQueueLong(queue, attributes_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }


        /// <summary>
        /// Insert List of Players
        /// </summary>
        /// <param name="entityList"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertPlayers(List<PlayerEntity> entityList)
        {
            var queue = new Queue<Rollback>();
            try
            {

                ///Insert into the main Players table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertPlayers.ToDescription().ToString());

                adObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                var players_id = insert(adObjCommand);
                if (players_id > 0)
                {
                    /// Now insert the detailed players to player table
                    foreach (var player in entityList)
                    {
                        var ret = insertPlayer(player, players_id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Tables.Player, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, players_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert List of Players
        /// </summary>
        /// <param name="entityList"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertPlayers(List<Player> entityList)
        {
            var queue = new Queue<Rollback>();
            try
            {
                ///Insert into the main Players table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertPlayers.ToDescription().ToString());

                adObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                var players_id = insert(adObjCommand);
                if (players_id > 0)
                {
                    /// Now insert the detailed players to player table
                    foreach (var player in entityList)
                    {
                        var ret = insertPlayer(player, players_id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Tables.Player, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, players_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Player
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertPlayer(Player entity, long? PlayersId)
        {
            var queue = new Queue<Rollback>();
            try
            {

                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertPlayer.ToDescription());
                if (entity.AdditionalData != null)
                {
                    var ret = insertAdditionalData(entity.AdditionalData);
                    if (ret.id != -1)
                    {
                        queue.Enqueue(SetRollback(ret.id, Tables.Dictionary, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                        adObjCommand.Parameters.AddWithValue("p_fk_dictionaries_additionaldata", NpgsqlDbType.Bigint, ret.id);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("p_fk_dictionaries_additionaldata", NpgsqlDbType.Bigint, DBNull.Value);
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_fk_dictionaries_additionaldata", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Attributes != null)
                {
                    var ret = insertAttributes(entity.Attributes);
                    if (ret.id != -1)
                    {
                        queue.Enqueue(SetRollback(ret.id, Tables.Attributes, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                        adObjCommand.Parameters.AddWithValue("p_fk_attributes_id", NpgsqlDbType.Bigint, ret.id);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("p_fk_attributes_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_fk_attributes_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_player_id", NpgsqlDbType.Integer, entity.Id);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_player_id", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.IsSubstitute != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_is_subtitute", NpgsqlDbType.Boolean, entity.IsSubstitute);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_is_subtitute", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.MatchRoles != null)
                {
                    var ret = insertMatchRoles(entity.MatchRoles);
                    if (ret.id != -1)
                    {
                        queue.Enqueue(SetRollback(ret.id, Tables.MatchRoles, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                        adObjCommand.Parameters.AddWithValue("p_is_subtitute", NpgsqlDbType.Bigint, ret.id);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("p_fk_match_roles_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_fk_match_roles_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Name != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_name", NpgsqlDbType.Text, entity.Name);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_name", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Nickname != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_nickname", NpgsqlDbType.Text, entity.Nickname);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_nickname", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Position))
                {
                    adObjCommand.Parameters.AddWithValue("p_position", NpgsqlDbType.Text, entity.Position);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_position", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.ShirtNumber != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_shirt_number", NpgsqlDbType.Integer, entity.ShirtNumber);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_shirt_number", NpgsqlDbType.Integer, DBNull.Value);
                }
                adObjCommand.Parameters.AddWithValue("p_fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);

                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }


        /// <summary>
        /// Insert Player
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertPlayer(PlayerEntity entity, long? PlayersId)
        {
            var queue = new Queue<Rollback>();
            try
            {

                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertPlayerEntity.ToDescription());

                if (entity.Id != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_player_id", entity.Id);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_player_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Name != null)
                {
                    var id = insertLocalizedString(entity.Name);
                    if (id > 0)
                    {
                        queue.Enqueue(SetRollback(id, Tables.MatchRoles, TransactionTypes.Insert));
                        adObjCommand.Parameters.AddWithValue("p_fk_localized_string_id", NpgsqlDbType.Bigint, id);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("p_fk_localized_string_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    adObjCommand.Parameters.AddWithValue("p_player_name", entity.Name.International);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_player_name", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Order != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_player_order", entity.Order);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_player_order", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.SuperId.HasValue)
                {
                    adObjCommand.Parameters.AddWithValue("p_super_id", entity.SuperId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_super_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.TeamId.HasValue)
                {
                    adObjCommand.Parameters.AddWithValue("p_fk_team_id", entity.TeamId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Texts != null && entity.Texts.Count > 0)
                {
                    var id = insertTexts(entity.Texts);
                    adObjCommand.Parameters.AddWithValue("p_fk_texts_id", id);
                    queue.Enqueue(SetRollback(id, Tables.Texts, TransactionTypes.Insert));
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_fk_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Value != null)
                {
                    adObjCommand.Parameters.AddWithValue("p_value", entity.Value);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("p_value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (PlayersId != null && PlayersId > 0)
                {
                    adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, PlayersId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert List of Managers
        /// </summary>
        /// <param name="entityList"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertManagers(List<Manager> entityList)
        {
            var queue = new Queue<Rollback>();
            try
            {
                ///Insert into the main Managers table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertManagers.ToDescription().ToString());

                adObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                var managers_id = insert(adObjCommand);
                if (managers_id > 0)
                {
                    /// Now insert the detailed managers to manager table
                    foreach (var manager in entityList)
                    {
                        var ret = insertManager(manager, managers_id);
                        if (ret.id != -1)
                        {
                            queue = CloneRollbackQueue(queue, ret.queue);
                            queue.Enqueue(SetRollback(ret.id, Tables.Manager, TransactionTypes.Insert));
                        }
                    }
                }
                return new ReturnQueueLong(queue, managers_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Manager
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertManager(Manager entity, long? ManagersId)
        {
            var queue = new Queue<Rollback>();
            try
            {

                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertManager.ToDescription());
                if (entity.Id != null)
                {
                    adObjCommand.Parameters.AddWithValue("manager_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("manager_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Name))
                {
                    adObjCommand.Parameters.AddWithValue("manager_name", NpgsqlDbType.Text, entity.Name);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("manager_name", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Team != null)
                {
                    adObjCommand.Parameters.AddWithValue("manager_id", NpgsqlDbType.Text, entity.Team.ToDescription());
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("manager_id", NpgsqlDbType.Text, DBNull.Value);
                }
                if (ManagersId != null && ManagersId > 0)
                {
                    adObjCommand.Parameters.AddWithValue("fk_managers_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_managers_id", NpgsqlDbType.Bigint, DBNull.Value);
                }

                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert bet results is a nested insert
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertBetResults(MatchEntity entity)
        {
            var queue = new Queue<Rollback>();
            ///Insert into the main Bet Result table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertBetResults.ToDescription());
            adObjCommand.Parameters.AddWithValue("is_deleted", false);
            try
            {

                var id = insert(adObjCommand);
                if (id != null && id > 0)
                {


                    /// Now insert the detailed Bet Result to Bet Result table
                    foreach (var betResult in entity.BetResults)
                    {
                        var betObjCommand = new NpgsqlCommand(DB_Functions.InsertBetResult.ToDescription());
                        if (betResult.OddsType != null)
                        {
                            betObjCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Bigint, betResult.OddsType);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        if (betResult.Outcome != null)
                        {
                            betObjCommand.Parameters.AddWithValue("outcome", NpgsqlDbType.Text, betResult.Outcome);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("outcome", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (betResult.OutcomeId != null)
                        {
                            betObjCommand.Parameters.AddWithValue("outcome_id", NpgsqlDbType.Text, betResult.Outcome);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("outcome_id", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (betResult.Reason != null)
                        {
                            betObjCommand.Parameters.AddWithValue("reason", NpgsqlDbType.Text, betResult.Reason);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("reason", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (betResult.SpecialBetValue != null)
                        {
                            betObjCommand.Parameters.AddWithValue("special_bet_value", NpgsqlDbType.Text,
                                betResult.SpecialBetValue);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("special_bet_value", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (betResult.Status != null)
                        {
                            betObjCommand.Parameters.AddWithValue("status", NpgsqlDbType.Boolean, betResult.Status);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("status", NpgsqlDbType.Boolean, DBNull.Value);
                        }
                        if (betResult.VoidFactor != null)
                        {
                            betObjCommand.Parameters.AddWithValue("void_factor", NpgsqlDbType.Text, betResult.VoidFactor);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("void_factor", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (betResult.PlayerId != null)
                        {
                            betObjCommand.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint,
                                betResult.PlayerId);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        if (betResult.TeamId != null)
                        {
                            betObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, betResult.TeamId);
                        }
                        else
                        {
                            betObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        betObjCommand.Parameters.AddWithValue("fk_bet_results_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(insert(betObjCommand), Tables.Bet_Result, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert a list of texts
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertTexts(List<TextEntity> entity)
        {
            ///Insert into the main Cards table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertTexts.ToDescription());
            adObjCommand.Parameters.AddWithValue("table_id", NpgsqlDbType.Bigint, DBNull.Value);
            try
            {
                var id = insert(adObjCommand);
                foreach (var texts in entity)
                {
                    if (texts.Text.Count > 0)
                    {
                        foreach (var text in texts.Text)
                        {
                            insertText(text, id);
                        }
                    }
                    else
                    {
                        insertText(texts, id);
                    }
                }

                return id;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return -1;
            }
        }

        /// <summary>
        /// scores
        /// </summary>
        /// <param name="scores"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertSetScores(string[] scores)
        {
            var queue = new Queue<Rollback>();

            ///Insert into the main Messages table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertSetScores.ToDescription());
            adObjCommand.Parameters.AddWithValue("is_deleted", false);
            try
            {
                var SetScores_id = insert(adObjCommand);

                /// Now insert the detailed message to message table
                foreach (var score in scores)
                {
                    var scoreSetObjCommand = new NpgsqlCommand(DB_Functions.InsertSetScore.ToDescription());
                    scoreSetObjCommand.Parameters.AddWithValue("score", score);
                    scoreSetObjCommand.Parameters.AddWithValue("fk_set_scores_id", SetScores_id);
                    var id = insert(scoreSetObjCommand);
                    queue.Enqueue(SetRollback(id, Tables.SetScore, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, SetScores_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert bet stop reason
        /// </summary>
        /// <param name="id"></param>
        /// <param name="reason"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long inserBetStopReason(string id, string reason)
        {
            ///Insert into the Sport Stop reason. 
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertBetStopReason.ToDescription());
            try
            {
                adObjCommand.Parameters.AddWithValue("bet_stop_reason_id", id);
                adObjCommand.Parameters.AddWithValue("reason", reason);
                return insert(adObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return -1;
            }

        }

        /// <summary>
        /// Home away is a custom structure e.g. dictionary 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="haHomeAway"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertHomeAway<T>(HomeAway<T> haHomeAway)
        {
            ///Insert into the Home Away table 
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertHomeAway.ToDescription());
            try
            {
                if (haHomeAway.Team1 != null)
                    adObjCommand.Parameters.AddWithValue("team1", NpgsqlDbType.Integer, haHomeAway.Team1);
                else
                    adObjCommand.Parameters.AddWithValue("team1", NpgsqlDbType.Integer, DBNull.Value);
                if (haHomeAway.Team2 != null)
                    adObjCommand.Parameters.AddWithValue("team2", NpgsqlDbType.Integer, haHomeAway.Team2);
                else
                    adObjCommand.Parameters.AddWithValue("team2", NpgsqlDbType.Integer, DBNull.Value);
                return insert(adObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return -1;
            }
        }

        /// <summary>
        /// Insert TV Channel List
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertTvChannels(List<TvChannelEntity> entity)
        {
            var queue = new Queue<Rollback>();
            var channelsCommand = new NpgsqlCommand(DB_Functions.InsertTvChannels.ToDescription());
            try
            {
                channelsCommand.Parameters.AddWithValue("is_deleted", false);
                var channels_id = insert(channelsCommand);
                foreach (var channel in entity)
                {
                    queue.Enqueue(SetRollback(insertTvChannel(channel, channels_id), Tables.TvChannel, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, channels_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// insert single TV Channel
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="TvChannelsId"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertTvChannel(TvChannelEntity entity, long TvChannelsId)
        {

            var command = new NpgsqlCommand(DB_Functions.InsertTvChannel.ToDescription());
            try
            {
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("tvchannel_id", entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("tvchannel_id", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Name))
                {
                    command.Parameters.AddWithValue("name", entity.Name);
                }
                else
                {
                    command.Parameters.AddWithValue("name", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.StartDate != null)
                {
                    command.Parameters.AddWithValue("start_date", entity.StartDate);
                }
                else
                {
                    command.Parameters.AddWithValue("start_date", NpgsqlDbType.Date, DBNull.Value);
                }
                command.Parameters.AddWithValue("fk_channels_id", TvChannelsId);
                return insert(command);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return -1;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="queueElement"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertMatchHeader(MatchHeader queueElement)
        {
            var common = new Common();
            var queue = new Queue<Rollback>();
            try
            {
                /// Now insert the detailed Match Header to match_header table

                var messageObjCommand = new NpgsqlCommand(DB_Functions.InserMatchHeader.ToDescription());
                if (queueElement.Active != null)
                    messageObjCommand.Parameters.AddWithValue("active", queueElement.Active);
                else
                    messageObjCommand.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);

                if (queueElement.AutoTraded != null)
                    messageObjCommand.Parameters.AddWithValue("auto_traded", queueElement.AutoTraded);
                else
                    messageObjCommand.Parameters.AddWithValue("auto_traded", NpgsqlDbType.Boolean, DBNull.Value);

                if (queueElement.Balls != null)
                    messageObjCommand.Parameters.AddWithValue("balls", queueElement.Balls);
                else
                    messageObjCommand.Parameters.AddWithValue("balls", NpgsqlDbType.Integer, DBNull.Value);

                if (queueElement.Bases != null)
                    messageObjCommand.Parameters.AddWithValue("bases", queueElement.Bases);
                else
                    messageObjCommand.Parameters.AddWithValue("bases", NpgsqlDbType.Text, DBNull.Value);

                if (queueElement.Batter != null)
                {
                    var homeAway_id = insertHomeAway(queueElement.Batter);
                    if (homeAway_id != null && homeAway_id > 0)
                    {
                        queue.Enqueue(SetRollback(homeAway_id, Tables.HomeAway, TransactionTypes.Insert));
                        messageObjCommand.Parameters.AddWithValue("fk_home_away_id_batter", NpgsqlDbType.Bigint, queueElement.Active);
                    }
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_batter", NpgsqlDbType.Bigint, DBNull.Value);

                if (queueElement.BetStatus != null)
                {
                    var enum_id = selectEnumValue(MasterEnum.EventBetStatus.ToDescription(),
                        queueElement.BetStatus.ToString());
                    var ggd = new enum_grouping();
                    if (queueElement.BetStatus.HasValue)
                        ggd.master = int.Parse(queueElement.BetStatus.Value.ToString());
                    ggd.slave = enum_id;
                    messageObjCommand.Parameters.AddWithValue("bet_status", ggd);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("bet_status", NpgsqlDbType.Composite, DBNull.Value);

                if (queueElement.BetStopReason != null)
                {
                    var id = inserBetStopReason(queueElement.BetStopReason.Id, queueElement.BetStopReason.Reason);
                    queue.Enqueue(SetRollback(id, Tables.BetStopReason, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_bet_stop_reason_id", NpgsqlDbType.Bigint, id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_bet_stop_reason_id", NpgsqlDbType.Bigint, DBNull.Value);

                if (queueElement.Booked != null)
                    messageObjCommand.Parameters.AddWithValue("booked", NpgsqlDbType.Boolean, queueElement.Booked.Value);
                else
                    messageObjCommand.Parameters.AddWithValue("booked", NpgsqlDbType.Boolean, DBNull.Value);
                if (queueElement.ClearedScore != null)
                    messageObjCommand.Parameters.AddWithValue("cleared_score", NpgsqlDbType.Text, queueElement.ClearedScore);
                else
                    messageObjCommand.Parameters.AddWithValue("cleared_score", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.ClockStopped != null)
                    messageObjCommand.Parameters.AddWithValue("clock_stopped", NpgsqlDbType.Boolean, queueElement.ClockStopped);
                else
                    messageObjCommand.Parameters.AddWithValue("clock_stopped", NpgsqlDbType.Boolean, DBNull.Value);
                if (queueElement.Corners != null)
                {
                    var id = insertHomeAway(queueElement.Corners);
                    queue.Enqueue(SetRollback(id, Tables.Corners, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_corners", NpgsqlDbType.Bigint, queueElement.Active);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_corners", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.CurrentCtTeam != null)
                {
                    var id = selectEnumValue(MasterEnum.Team.ToDescription(), queueElement.CurrentCtTeam.ToString());
                    messageObjCommand.Parameters.AddWithValue("current_ct_team", id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("current_ct_team", NpgsqlDbType.Composite, DBNull.Value);
                if (queueElement.CurrentEnd != null)
                    messageObjCommand.Parameters.AddWithValue("current_end", NpgsqlDbType.Integer, queueElement.CurrentEnd);
                else
                    messageObjCommand.Parameters.AddWithValue("current_end", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Delivery != null)
                {
                    var enums = selectEnumValue(MasterEnum.Team.ToDescription(), queueElement.Delivery.ToString());
                    messageObjCommand.Parameters.AddWithValue("delivery", enums);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("delivery", NpgsqlDbType.Composite, DBNull.Value);
                if (queueElement.Dismissals != null)
                {
                    var id = insertHomeAway(queueElement.Dismissals);
                    queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_dismissals_id", NpgsqlDbType.Bigint, id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_dismissals_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.EarlyBetStatus != null)
                {
                    var enums = selectEnumValue(MasterEnum.OddsMatchEarlyBetStatus.ToDescription(),
                         queueElement.EarlyBetStatus.ToString());
                    messageObjCommand.Parameters.AddWithValue("early_bet_status", enums);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("early_bet_status", NpgsqlDbType.Composite, DBNull.Value);
                if (queueElement.Expedite != null)
                    messageObjCommand.Parameters.AddWithValue("expedite", NpgsqlDbType.Boolean, queueElement.Expedite);
                else
                    messageObjCommand.Parameters.AddWithValue("expedite", NpgsqlDbType.Boolean, DBNull.Value);
                if (queueElement.GameScore != null)
                    messageObjCommand.Parameters.AddWithValue("game_score", NpgsqlDbType.Text, queueElement.GameScore);
                else
                    messageObjCommand.Parameters.AddWithValue("game_score", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.Id != null)
                    messageObjCommand.Parameters.AddWithValue("event_id", queueElement.Id);
                else
                    messageObjCommand.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.Innings != null)
                    messageObjCommand.Parameters.AddWithValue("innings", queueElement.Active);
                else
                    messageObjCommand.Parameters.AddWithValue("innings", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.LegScore != null)
                    messageObjCommand.Parameters.AddWithValue("leg_score", queueElement.Active);
                else
                    messageObjCommand.Parameters.AddWithValue("leg_score", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.MatchTime != null)
                    messageObjCommand.Parameters.AddWithValue("match_time", NpgsqlDbType.Bigint, queueElement.MatchTime);
                else
                    messageObjCommand.Parameters.AddWithValue("match_time", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.MatchTimeExtended != null)
                    messageObjCommand.Parameters.AddWithValue("match_time_extended", NpgsqlDbType.Text, queueElement.MatchTimeExtended);
                else
                    messageObjCommand.Parameters.AddWithValue("match_time_extended", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.Message != null)
                {
                    var ret = insertMessages(queueElement.Message);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    queue = CloneRollbackQueue(queue, ret.queue);
                    messageObjCommand.Parameters.AddWithValue("fk_messages_id", ret.id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.Msgnr != null)
                    messageObjCommand.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, queueElement.Msgnr);
                else
                    messageObjCommand.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.Outs != null)
                    messageObjCommand.Parameters.AddWithValue("outs", NpgsqlDbType.Integer, queueElement.Outs);
                else
                    messageObjCommand.Parameters.AddWithValue("outs", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Over != null)
                    messageObjCommand.Parameters.AddWithValue("over", NpgsqlDbType.Integer, queueElement.Over);
                else
                    messageObjCommand.Parameters.AddWithValue("over", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.PentaltyRuns != null)
                {
                    var id = insertHomeAway(queueElement.PentaltyRuns);
                    queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_pental_runs", id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_pental_runs", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.Position != null)
                    messageObjCommand.Parameters.AddWithValue("position", NpgsqlDbType.Integer, queueElement.Position);
                else
                    messageObjCommand.Parameters.AddWithValue("position", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Possession != null)
                {
                    var enums = selectEnumValue(MasterEnum.Team.ToDescription(), queueElement.Possession.ToString());
                    messageObjCommand.Parameters.AddWithValue("possession", enums);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("possession", NpgsqlDbType.Composite, DBNull.Value);
                if (queueElement.RedCards != null)
                {
                    var id = insertHomeAway(queueElement.RedCards);
                    queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_red_cards", id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_red_cards", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.RemainingBowls != null)
                    messageObjCommand.Parameters.AddWithValue("remaining_bowls", NpgsqlDbType.Integer, queueElement.RemainingBowls);
                else
                    messageObjCommand.Parameters.AddWithValue("remaining_bowls", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.RemainingReds != null)
                    messageObjCommand.Parameters.AddWithValue("remaining_reds", NpgsqlDbType.Integer, queueElement.RemainingReds);
                else
                    messageObjCommand.Parameters.AddWithValue("remaining_reds", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.RemainingTime != null)
                    messageObjCommand.Parameters.AddWithValue("remaining_time", NpgsqlDbType.Text, queueElement.RemainingTime);
                else
                    messageObjCommand.Parameters.AddWithValue("remaining_time", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.RemainingTimeInPeriod != null)
                    messageObjCommand.Parameters.AddWithValue("remaining_time_in_period", queueElement.RemainingTimeInPeriod);
                else
                    messageObjCommand.Parameters.AddWithValue("remaining_time_in_period", DBNull.Value);
                if (queueElement.Score != null)
                    messageObjCommand.Parameters.AddWithValue("score", NpgsqlDbType.Text, queueElement.Score);
                else
                    messageObjCommand.Parameters.AddWithValue("score", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.Server != null)
                    messageObjCommand.Parameters.AddWithValue("server", NpgsqlDbType.Integer, queueElement.Server);
                else
                    messageObjCommand.Parameters.AddWithValue("server", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.SetScores != null)
                {
                    var ret = insertSetScores(queueElement.SetScores);
                    queue.Enqueue(SetRollback(ret.id, Tables.SetScores, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_set_scores_id", NpgsqlDbType.Bigint, ret.id);
                    queue = CloneRollbackQueue(queue, ret.queue);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_set_scores_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.SourceId != null)
                    messageObjCommand.Parameters.AddWithValue("source_id", NpgsqlDbType.Text, queueElement.SourceId);
                else
                    messageObjCommand.Parameters.AddWithValue("source_id", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.Status != null)
                {
                    var enums = selectEnumValue(MasterEnum.EventStatus.ToDescription(), queueElement.Status.ToString());
                    messageObjCommand.Parameters.AddWithValue("status", enums);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("status", NpgsqlDbType.Composite, DBNull.Value);
                if (queueElement.Strikes != null)
                    messageObjCommand.Parameters.AddWithValue("strikes", NpgsqlDbType.Integer, queueElement.Strikes);
                else
                    messageObjCommand.Parameters.AddWithValue("strikes", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Suspend != null)
                {
                    var id = insertHomeAway(queueElement.Suspend);
                    queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_suspend", NpgsqlDbType.Bigint, id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_suspend", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.Throw != null)
                    messageObjCommand.Parameters.AddWithValue("throw", NpgsqlDbType.Integer, queueElement.Throw);
                else
                    messageObjCommand.Parameters.AddWithValue("throw", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.TieBreak != null)
                    messageObjCommand.Parameters.AddWithValue("tie_break", NpgsqlDbType.Integer, queueElement.TieBreak);
                else
                    messageObjCommand.Parameters.AddWithValue("tie_break", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Try != null)
                    messageObjCommand.Parameters.AddWithValue("try", NpgsqlDbType.Integer, queueElement.Try);
                else
                    messageObjCommand.Parameters.AddWithValue("try", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Visit != null)
                    messageObjCommand.Parameters.AddWithValue("visit", NpgsqlDbType.Integer, queueElement.Visit);
                else
                    messageObjCommand.Parameters.AddWithValue("visit", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.Yards != null)
                    messageObjCommand.Parameters.AddWithValue("yards", NpgsqlDbType.Integer, queueElement.Yards);
                else
                    messageObjCommand.Parameters.AddWithValue("yards", NpgsqlDbType.Integer, DBNull.Value);
                if (queueElement.YellowCards != null)
                {
                    var id = insertHomeAway(queueElement.YellowCards);
                    queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_yellow_cards", NpgsqlDbType.Bigint, id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_yellow_cards", NpgsqlDbType.Bigint, DBNull.Value);
                if (queueElement.YellowRedCards != null)
                {
                    var id = insertHomeAway(queueElement.YellowRedCards);
                    queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_yellow_red_cards", NpgsqlDbType.Bigint, id);
                }
                else
                    messageObjCommand.Parameters.AddWithValue("fk_home_away_id_yellow_red_cards", NpgsqlDbType.Bigint, DBNull.Value);

                return new ReturnQueueLong(queue, insert(messageObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Texts as a bundler only not detail
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertTexts(List<TextsEntity> entity)
        {
            var queue = new Queue<Rollback>();
            ///Insert into the main Cards table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertTexts.ToDescription());
            adObjCommand.Parameters.AddWithValue("table_id", NpgsqlDbType.Bigint, DBNull.Value);
            try
            {
                var id = insert(adObjCommand);
                foreach (var texts in entity)
                {
                    foreach (var text in texts.Texts)
                    {
                        var ret = insertText(text, id);
                        if (ret.id != -1)
                        {
                            queue.Enqueue(SetRollback(ret.id, Tables.Text, TransactionTypes.Insert));
                        }
                    }
                }
                return new ReturnQueueLong(queue, id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Texts with another functionality
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertTexts(TextsEntity entity)
        {
            var queue = new Queue<Rollback>();
            ///Insert into the main Cards table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertTexts.ToDescription());
            adObjCommand.Parameters.AddWithValue("table_id", NpgsqlDbType.Bigint, DBNull.Value);
            try
            {
                var id = insert(adObjCommand);
                foreach (var texts in entity.Texts)
                {
                    var retParent = insertText(texts, id);
                    if (retParent.id != -1)
                    {
                        queue.Enqueue(SetRollback(retParent.id, Tables.Text, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert texts while sending the grouper texts id 
        /// </summary>
        /// <param name="textEntity"></param>
        /// <param name="textsId"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertText(TextEntity textEntity, long textsId)
        {

            var queue = new Queue<Rollback>();
            var parent_text_id = 0;
            var hasChildren = false;
            var textObjCommand = new NpgsqlCommand(DB_Functions.InsertText.ToDescription());
            try
            {

                if (textEntity.Superid != null)
                {
                    textObjCommand.Parameters.AddWithValue("super_id", NpgsqlDbType.Bigint, textEntity.Superid);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("super_id", NpgsqlDbType.Bigint, DBNull.Value);
                }

                if (textEntity.Type != null)
                {
                    textObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, textEntity.Type);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(textEntity.Language))
                {
                    textObjCommand.Parameters.AddWithValue("language", textEntity.Language);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("language", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(textEntity.Value))
                {
                    textObjCommand.Parameters.AddWithValue("value", textEntity.Value);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (textEntity.Text != null && textEntity.Text.Count > 0)
                {
                    hasChildren = true;
                    textObjCommand.Parameters.AddWithValue("parent_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("parent_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                textObjCommand.Parameters.AddWithValue("fk_texts_id", textsId);
                var id = insert(textObjCommand);
                if (hasChildren && id > 0)
                {
                    foreach (var text in textEntity.Text)
                    {
                        var ret = insertTextChild(text, id);
                        if (ret.id != -1)
                        {
                            queue = CloneRollbackQueue(queue, ret.queue);
                            queue.Enqueue(SetRollback(ret.id, Tables.Text, TransactionTypes.Insert));
                        }
                    }
                }
                return new ReturnQueueLong(queue, id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }

        }

        /// <summary>
        /// Insert Child texts while sending the Parent text id 
        /// </summary>
        /// <param name="textEntity"></param>
        /// <param name="parentId"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertTextChild(TextEntity textEntity, long parentId)
        {

            var queue = new Queue<Rollback>();
            var parent_text_id = 0;
            var textObjCommand = new NpgsqlCommand(DB_Functions.InsertText.ToDescription());
            try
            {

                if (textEntity.Superid != null)
                {
                    textObjCommand.Parameters.AddWithValue("super_id", NpgsqlDbType.Bigint, textEntity.Superid);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("super_id", NpgsqlDbType.Bigint, DBNull.Value);
                }

                if (textEntity.Type != null)
                {
                    textObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, textEntity.Type);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(textEntity.Language))
                {
                    textObjCommand.Parameters.AddWithValue("language", textEntity.Language);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("language", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(textEntity.Value))
                {
                    textObjCommand.Parameters.AddWithValue("value", textEntity.Value);
                }
                else
                {
                    textObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                textObjCommand.Parameters.AddWithValue("parent_id", NpgsqlDbType.Bigint, parentId);
                textObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                return new ReturnQueueLong(queue, insert(textObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }

        }

        /// <summary>
        /// Insert BetFair 
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertBetFairId(BetfairIdEntity entity)
        {
            ///Insert into the main dictionary table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertBetfairId.ToDescription());
            try
            {

                if (entity.Runner1 != null)
                {
                    adObjCommand.Parameters.AddWithValue("runner_1", NpgsqlDbType.Integer, entity.Runner1);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("runner_1", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.Runner2 != null)
                {
                    adObjCommand.Parameters.AddWithValue("runner_2", NpgsqlDbType.Integer, entity.Runner2);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("runner_2", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.EventId != null)
                {
                    adObjCommand.Parameters.AddWithValue("fx_event_id", NpgsqlDbType.Bigint, entity.EventId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fx_event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.SportId != null)
                {
                    adObjCommand.Parameters.AddWithValue("fx_sport_id", NpgsqlDbType.Bigint, entity.SportId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fx_sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                var id = insert(adObjCommand);
                return id;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                throw;
            }
        }

        /// <summary>
        /// Additional data Insert
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertAdditionalData(ScoreCardSummary entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                //TODO: this function is not finished
                ///Insert into the main dictionary table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertDictionaries.ToDescription());
                adObjCommand.Parameters.AddWithValue("fk_table_id", Tables.Live_Common_Feed.ToDescription());
                var dictionaries_id = insert(adObjCommand);

                /// Now insert the detailed dictionaries to dictionary table
                foreach (var dictionary in entity.AdditionalData)
                {
                    var dictionaryObjCommand = new NpgsqlCommand(DB_Functions.InserDictionary.ToDescription());
                    dictionaryObjCommand.Parameters.AddWithValue("fk_table_id", NpgsqlDbType.Integer, Tables.Dictionary.ToDescription());
                    dictionaryObjCommand.Parameters.AddWithValue("dictionaries_id", dictionaries_id);
                    dictionaryObjCommand.Parameters.AddWithValue("key", dictionary.Key);
                    dictionaryObjCommand.Parameters.AddWithValue("value", dictionary.Value);
                    queue.Enqueue(SetRollback(insert(dictionaryObjCommand), Tables.Dictionary, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, dictionaries_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Additional data Insert
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertAdditionalData(LineupsEventArgs entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                //TODO: this function is not finished
                ///Insert into the main dictionary table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertDictionaries.ToDescription());
                adObjCommand.Parameters.AddWithValue("fk_table_id", Tables.Live_Common_Feed.ToDescription());
                var dictionaries_id = insert(adObjCommand);

                /// Now insert the detailed dictionaries to dictionary table
                foreach (var dictionary in entity.Lineups.AdditionalData)
                {
                    var dictionaryObjCommand = new NpgsqlCommand(DB_Functions.InserDictionary.ToDescription());
                    dictionaryObjCommand.Parameters.AddWithValue("fk_table_id", NpgsqlDbType.Integer, Tables.Dictionary.ToDescription());
                    dictionaryObjCommand.Parameters.AddWithValue("dictionaries_id", dictionaries_id);
                    dictionaryObjCommand.Parameters.AddWithValue("key", dictionary.Key);
                    dictionaryObjCommand.Parameters.AddWithValue("value", dictionary.Value);
                    queue.Enqueue(SetRollback(insert(dictionaryObjCommand), Tables.Dictionary, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, dictionaries_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Additional data in Dictionaries
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public ReturnQueueLong insertAdditionalData(IDictionary<string, string> entity)
        {
            var queue = new Queue<Rollback>();
            ///Insert into the main dictionary table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertDictionaries.ToDescription());
            adObjCommand.Parameters.AddWithValue("fk_table_id", NpgsqlDbType.Integer, Tables.Live_Common_Feed);
            try
            {

                var dictionaries_id = insert(adObjCommand);
                if (dictionaries_id > 0)
                {
                    /// Now insert the detailed dictionaries to dictionary table
                    foreach (var dictionary in entity)
                    {
                        var dictionaryObjCommand = new NpgsqlCommand(DB_Functions.InserDictionary.ToDescription());
                        dictionaryObjCommand.Parameters.AddWithValue("fk_table_id", NpgsqlDbType.Bigint, DBNull.Value);
                        dictionaryObjCommand.Parameters.AddWithValue("dictionaries_id", NpgsqlDbType.Bigint, dictionaries_id);
                        if (!string.IsNullOrEmpty(dictionary.Key))
                        {
                            dictionaryObjCommand.Parameters.AddWithValue("key", NpgsqlDbType.Text, dictionary.Key);
                        }
                        else
                        {
                            dictionaryObjCommand.Parameters.AddWithValue("key", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(dictionary.Value))
                        {
                            dictionaryObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, dictionary.Value);
                        }
                        else
                        {
                            dictionaryObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                        }

                        queue.Enqueue(SetRollback(insert(dictionaryObjCommand), Tables.Dictionary, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, dictionaries_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        public long insertAggregateScore(AggregateScoreEntity queueElement)
        {
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertAggregateScore.ToDescription());
            try
            {
                if (!string.IsNullOrEmpty(queueElement.Value))
                {
                    adObjCommand.Parameters.AddWithValue("value", queueElement.Value);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("value", DBNull.Value);
                }
                if (!string.IsNullOrEmpty(queueElement.Winner))
                {
                    adObjCommand.Parameters.AddWithValue("winner", queueElement.Winner);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("winner", DBNull.Value);
                }
                adObjCommand.Parameters.AddWithValue("fk_team_id", DBNull.Value);

                return insert(adObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return -1;
            }
        }
        public ReturnQueueLong insertCompetitors(CompetitorsEntity queueElement)
        {
            var queue = new Queue<Rollback>();
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertCompetitors.ToDescription());
            try
            {
                if (queueElement.Players != null && queueElement.Players.Count > 0)
                {
                    var ret = insertPlayers(queueElement.Players);
                    if (ret.id != -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Tables.Players, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (queueElement.Texts != null)
                {
                    var ret = insertTexts(queueElement.Texts);

                    if (ret.id != -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Tables.Players, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Fixture part of the Match entity insert
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertFixture(FixtureEntity entity)
        {
            var queue = new Queue<Rollback>();
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertFixture.ToDescription());
            try
            {
                if (entity.AamsCalendarId != null)
                {
                    adObjCommand.Parameters.AddWithValue("aamscalendar_id", NpgsqlDbType.Bigint, entity.AamsCalendarId);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("aamscalendar_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.AggregateScore != null)
                {
                    var id = insertAggregateScore(entity.AggregateScore);
                    if (id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fx_aggregate_score_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fx_aggregate_score_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.Aggregate_Score, TransactionTypes.Insert));
                    }
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fx_aggregate_score_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.AustrianDistrict != null)
                {
                    adObjCommand.Parameters.AddWithValue("austrian_district", NpgsqlDbType.Bigint, entity.AustrianDistrict);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("austrian_district", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Competitors != null)
                {
                    var ret = insertCompetitors(entity.Competitors);
                    if (ret.id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_competitors_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_competitors_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Tables.Competitors, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_competitors_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.DateInfo != null)
                {
                    var ret = insertDateinfo(entity.DateInfo);
                    if (ret.id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_date_info_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_date_info_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Tables.Date_Info, TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_date_info_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                adObjCommand.Parameters.AddWithValue("fx_tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (entity.EventInfo != null)
                {
                    var ret = insertEventInfo(entity.EventInfo);
                    if (ret.id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_event_info_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_event_info_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_event_info_id", NpgsqlDbType.Bigint, DBNull.Value); // heytham
                }
                if (entity.HasStatistics != null)
                {
                    adObjCommand.Parameters.AddWithValue("has_statistics", NpgsqlDbType.Boolean, entity.HasStatistics);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("has_statistics", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.LiveMultiCast != null)
                {
                    adObjCommand.Parameters.AddWithValue("live_multi_cast", NpgsqlDbType.Boolean, entity.LiveMultiCast);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("live_multi_cast", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.LiveScore != null)
                {
                    adObjCommand.Parameters.AddWithValue("live_score", NpgsqlDbType.Boolean, entity.LiveScore);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("live_score", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.NeutralGround != null)
                {
                    adObjCommand.Parameters.AddWithValue("neutral_ground", NpgsqlDbType.Boolean, entity.NeutralGround);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("neutral_ground", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.NumberOfFrames != null)
                {
                    adObjCommand.Parameters.AddWithValue("number_of_frames", NpgsqlDbType.Integer, entity.NumberOfFrames);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("number_of_frames", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.NumberOfSets != null)
                {
                    adObjCommand.Parameters.AddWithValue("number_of_sets", NpgsqlDbType.Bigint, entity.NumberOfSets);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("number_of_sets", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Players != null)
                {
                    var ret = insertPlayers(entity.Players.Players);
                    if (ret.id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_players_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.RoundInfo != null)
                {
                    var id = insertRoundInfo(entity.RoundInfo);
                    if (id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_round_info_id", NpgsqlDbType.Bigint, id);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_round_info_id", NpgsqlDbType.Bigint, id);
                    }

                    queue.Enqueue(SetRollback(id, Tables.Round_Info, TransactionTypes.Insert));
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_round_info_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.SeriesResult != null)
                {
                    var id = insertSeriesResult(entity.SeriesResult);
                    if (id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_series_result_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_series_result_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.Round_Info, TransactionTypes.Insert));
                    }
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_series_result_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.StatusInfo != null)
                {
                    adObjCommand.Parameters.AddWithValue("status_info", NpgsqlDbType.Boolean, entity.StatusInfo.IsActive);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("status_info", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Venue != null)
                {
                    var id = insertVenue(entity.Venue);
                    if (id == -1)
                    {
                        adObjCommand.Parameters.AddWithValue("fk_venue_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        adObjCommand.Parameters.AddWithValue("fk_venue_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.Venue, TransactionTypes.Insert));
                    }

                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("fk_venue_id", DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(adObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }
        public long insertVenue(VenueEntity entity)
        {
            var queue = new Queue<Rollback>();
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertVenue.ToDescription());
            try
            {

                if (!string.IsNullOrEmpty(entity.Value))
                {
                    ObjCommand.Parameters.AddWithValue("value", entity.Value);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("value", DBNull.Value);
                }
                if (entity.Id != null)
                {
                    ObjCommand.Parameters.AddWithValue("venueid", entity.Id);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("venueid", DBNull.Value);
                }
                if (entity.Coordinates != null)
                {
                    var id = insertCoordinates(entity.Coordinates);
                    ObjCommand.Parameters.AddWithValue("coordinates_id", id);
                    queue.Enqueue(SetRollback(id, Tables.Coordinates, TransactionTypes.Insert));
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("coordinates_id", DBNull.Value);
                }
                if (entity.Texts != null)
                {
                    var id = insertTexts(entity.Texts);
                    ObjCommand.Parameters.AddWithValue("fk_texts_id", id);
                    queue.Enqueue(SetRollback(id, Tables.Texts, TransactionTypes.Insert));
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("fk_texts_id", DBNull.Value);
                }

                return insert(ObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }
        public long insertCoordinates(CoordinatesEntity entity)
        {
            var queue = new Queue<Rollback>();
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertSeriesResult.ToDescription());
            try
            {

                if (!string.IsNullOrEmpty(entity.Longitude.ToString()))
                {
                    ObjCommand.Parameters.AddWithValue("longitudes", entity.Longitude.ToString());
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("longitudes", DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Latitude.ToString()))
                {
                    ObjCommand.Parameters.AddWithValue("latitudes", entity.Latitude.ToString());
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("latitudes", DBNull.Value);
                }
                long ids = 0;
                ids = insert(ObjCommand);
                return ids;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// Insert Series Result
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertSeriesResult(SeriesResultEntity entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                var ObjCommand = new NpgsqlCommand(DB_Functions.InsertSeriesResult.ToDescription());

                if (!string.IsNullOrEmpty(entity.Value))
                {
                    ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, entity.Value);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Winner))
                {
                    ObjCommand.Parameters.AddWithValue("winner", NpgsqlDbType.Text, entity.Winner);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("winner", NpgsqlDbType.Text, DBNull.Value);
                }
                ObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                long ids = 0;
                ids = insert(ObjCommand);
                return ids;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Insert Round info
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertRoundInfo(RoundInfoEntity entity)
        {
            var queue = new Queue<Rollback>();
            try
            {

                var ObjCommand = new NpgsqlCommand(DB_Functions.InsertRountInfo.ToDescription());

                if (!string.IsNullOrEmpty(entity.Cupround))
                {
                    ObjCommand.Parameters.AddWithValue("cup_round", NpgsqlDbType.Text, entity.Cupround);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("cup_round", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.MatchNr))
                {
                    ObjCommand.Parameters.AddWithValue("match_nr", NpgsqlDbType.Text, entity.MatchNr);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("match_nr", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Round != null)
                {
                    ObjCommand.Parameters.AddWithValue("round", NpgsqlDbType.Integer, entity.Round);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("round", NpgsqlDbType.Integer, DBNull.Value);
                }
                long ids = 0;
                ids = insert(ObjCommand);
                return ids;

            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Insert Event Info
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertEventInfo(EventInfoEntity entity)
        {
            var queue = new Queue<Rollback>();
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertEventInfo.ToDescription());

            ObjCommand.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
            if (entity.EventDate != null)
            {
                ObjCommand.Parameters.AddWithValue("event_date", NpgsqlDbType.Timestamp, entity.EventDate);
            }
            else
            {
                ObjCommand.Parameters.AddWithValue("event_date", NpgsqlDbType.Timestamp, DBNull.Value);
            }
            if (entity.EventEndDate != null)
            {
                ObjCommand.Parameters.AddWithValue("event_end_date", NpgsqlDbType.Timestamp, entity.EventEndDate);
            }
            else
            {
                ObjCommand.Parameters.AddWithValue("event_end_date", NpgsqlDbType.Timestamp, DBNull.Value);
            }
            if (entity.EventName != null)
            {
                var ret = insertTexts(entity.EventName);
                if (ret.id == -1)
                {
                    ObjCommand.Parameters.AddWithValue("fx_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("fx_texts_id", NpgsqlDbType.Bigint, ret.id);
                    queue.Enqueue(SetRollback(ret.id, Tables.Event_Info, TransactionTypes.Insert));
                }

            }
            else
            {
                ObjCommand.Parameters.AddWithValue("fx_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
            }
            if (entity.EventStart != null)
            {
                ObjCommand.Parameters.AddWithValue("event_start", NpgsqlDbType.Timestamp, entity.EventStart);
            }
            else
            {
                ObjCommand.Parameters.AddWithValue("event_start", NpgsqlDbType.Timestamp, DBNull.Value);
            }

            //ObjCommand.Parameters.AddWithValue("status", NpgsqlDbType.Boolean, DBNull.Value);

            if (entity.TournamentId != null)
            {
                ObjCommand.Parameters.AddWithValue("fx_tournament_id", NpgsqlDbType.Bigint, entity.TournamentId);
            }
            else
            {
                ObjCommand.Parameters.AddWithValue("fx_tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
            }

            try
            {
                return new ReturnQueueLong(queue, insert(ObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }

        }

        /// <summary>
        /// Insert List of Bet type
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public ReturnQueueLong insertBets(List<BetEntity> entity, long? MatchId)
        {
            long ids = 0;
            var queue = new Queue<Rollback>();
            try
            {
                var BetsCommand = new NpgsqlCommand(DB_Functions.InsertBets.ToDescription());
                BetsCommand.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Boolean, false);
                var Bets_id = insert(BetsCommand);
                ids = Bets_id;
                foreach (var bet in entity)
                {
                    //Insert BetOdds value which is only a grouping table for odds
                    var BetOddsCommand = new NpgsqlCommand(DB_Functions.InsertBetOdds.ToDescription());
                    BetOddsCommand.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Boolean, false);
                    var BetOdds_id = insert(BetOddsCommand);
                    queue.Enqueue(SetRollback(BetOdds_id, Tables.BetOdds, TransactionTypes.Insert));
                    var BetCommand = new NpgsqlCommand(DB_Functions.InsertBet.ToDescription());
                    BetCommand.Parameters.AddWithValue("match_id", NpgsqlDbType.Bigint, MatchId);
                    if (bet.OddsType != null)
                    {
                        BetCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Integer, bet.OddsType);
                    }
                    else
                    {
                        BetCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Integer, DBNull.Value);
                    }
                    BetCommand.Parameters.AddWithValue("fk_match_odds_id", NpgsqlDbType.Bigint, BetOdds_id);
                    BetCommand.Parameters.AddWithValue("bet_id", NpgsqlDbType.Bigint, Bets_id);
                    var Bet_id = insert(BetCommand);
                    queue.Enqueue(SetRollback(Bet_id, Tables.Bet, TransactionTypes.Insert));
                    foreach (var odd in bet.Odds)
                    {
                        var OddCommand = new NpgsqlCommand(DB_Functions.InsertOdds.ToDescription());

                        if (odd.Id != null)
                        {
                            OddCommand.Parameters.AddWithValue("odds_id", odd.Id);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("odds_id", DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(odd.OutCome))
                        {
                            OddCommand.Parameters.AddWithValue("outcome", odd.OutCome);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("outcome", DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(odd.OutcomeId))
                        {
                            OddCommand.Parameters.AddWithValue("outcome_id", odd.OutCome);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("outcome_id", DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(odd.PlayerId))
                        {
                            OddCommand.Parameters.AddWithValue("player_id", odd.PlayerId);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("player_id", DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(odd.SpecialBetValue))
                        {
                            OddCommand.Parameters.AddWithValue("special_bet_value", odd.SpecialBetValue);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("special_bet_value", DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(odd.TeamId))
                        {
                            OddCommand.Parameters.AddWithValue("team_id", odd.TeamId);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("team_id", DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(odd.Value))
                        {
                            OddCommand.Parameters.AddWithValue("value", odd.Value);
                        }
                        else
                        {
                            OddCommand.Parameters.AddWithValue("value", DBNull.Value);
                        }
                        OddCommand.Parameters.AddWithValue("fk_bet_id", Bet_id);
                        var Odd_id = insert(OddCommand);
                        queue.Enqueue(SetRollback(Odd_id, Tables.Odds, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, ids);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert single Bet type
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public ReturnQueueLong insertBets(BetEntity entity)
        {
            long ids = 0;
            var queue = new Queue<Rollback>();
            try
            {
                //Insert BetOdds value which is only a grouping table for odds
                var BetOddsCommand = new NpgsqlCommand(DB_Functions.InsertBetOdds.ToDescription());
                BetOddsCommand.Parameters.AddWithValue("is_deleted", false);
                var BetOdds_id = insert(BetOddsCommand);
                ids = BetOdds_id;
                var BetCommand = new NpgsqlCommand(DB_Functions.InsertBet.ToDescription());
                BetCommand.Parameters.AddWithValue("match_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (entity.OddsType != null)
                {
                    BetCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Integer, entity.OddsType);
                }
                else
                {
                    BetCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Integer, DBNull.Value);
                }
                BetCommand.Parameters.AddWithValue("fk_match_odds_id", NpgsqlDbType.Bigint, BetOdds_id);
                BetCommand.Parameters.AddWithValue("bet_id", NpgsqlDbType.Bigint, DBNull.Value);
                var Bet_id = insert(BetCommand);
                queue.Enqueue(SetRollback(Bet_id, Tables.Bet, TransactionTypes.Insert));
                foreach (var odd in entity.Odds)
                {
                    var OddCommand = new NpgsqlCommand(DB_Functions.InsertOdds.ToDescription());

                    if (odd.Id != null)
                    {
                        OddCommand.Parameters.AddWithValue("odds_id", odd.Id);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("odds_id", DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(odd.OutCome))
                    {
                        OddCommand.Parameters.AddWithValue("outcome", odd.OutCome);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("outcome", DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(odd.OutcomeId))
                    {
                        OddCommand.Parameters.AddWithValue("outcome_id", odd.OutCome);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("outcome_id", DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(odd.PlayerId))
                    {
                        OddCommand.Parameters.AddWithValue("player_id", odd.PlayerId);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("player_id", DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(odd.SpecialBetValue))
                    {
                        OddCommand.Parameters.AddWithValue("special_bet_value", odd.SpecialBetValue);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("special_bet_value", DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(odd.TeamId))
                    {
                        OddCommand.Parameters.AddWithValue("team_id", odd.TeamId);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("team_id", DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(odd.Value))
                    {
                        OddCommand.Parameters.AddWithValue("value", odd.Value);
                    }
                    else
                    {
                        OddCommand.Parameters.AddWithValue("value", DBNull.Value);
                    }
                    OddCommand.Parameters.AddWithValue("fk_bet_id", BetOdds_id);
                    var Odd_id = insert(OddCommand);
                    queue.Enqueue(SetRollback(Odd_id, Tables.Odds, TransactionTypes.Insert));
                }

            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                ids = -1;
            }
            var ret = new ReturnQueueLong();
            ret.id = ids;
            ret.queue = queue;
            return ret;
        }

        /// <summary>
        /// Insert Odds Probabilities
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public ReturnQueueLong insertOddsProbabilities(List<OddsProbabilityEntity> entity)
        {
            var queue = new Queue<Rollback>();
            var commands = new NpgsqlCommand(DB_Functions.InsertOddsProbabilities.ToDescription());
            commands.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Boolean, false);
            var oProbabilities_id = insert(commands);
            try
            {
                foreach (var oProb in entity)
                {
                    var command = new NpgsqlCommand(DB_Functions.InsertOddsProbability.ToDescription());
                    if (oProb.Id != null)
                    {
                        command.Parameters.AddWithValue("odds_id", NpgsqlDbType.Bigint, oProb.Id);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("odds_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(oProb.Outcome))
                    {
                        command.Parameters.AddWithValue("outcome", NpgsqlDbType.Text, oProb.Outcome);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("outcome", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(oProb.OutcomeId))
                    {
                        command.Parameters.AddWithValue("outcome_id", NpgsqlDbType.Text, oProb.OutcomeId);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("outcome_id", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(oProb.PlayerId))
                    {
                        command.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint, oProb.PlayerId);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (oProb.SpecialBetValue != null)
                    {
                        command.Parameters.AddWithValue("special_bet_value", NpgsqlDbType.Text, oProb.SpecialBetValue);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("special_bet_value", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(oProb.TeamId))
                    {
                        command.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, oProb.TeamId);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(oProb.Value))
                    {
                        command.Parameters.AddWithValue("value", NpgsqlDbType.Text, oProb.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (oProbabilities_id >0)
                    {
                        command.Parameters.AddWithValue("fk_odds_probabilities_id", NpgsqlDbType.Bigint, oProbabilities_id);
                        var id = insert(command);
                        queue.Enqueue(SetRollback(id, Tables.Odds_Probability, TransactionTypes.Insert));
                    }
                    
                }
                return new ReturnQueueLong(queue, oProbabilities_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// insert Probabilities
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public ReturnQueueLong insertProbabilities(List<ProbabilityEntity> entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                //Insert probabilities row to set then probability table
                var ProbabilitiesCommand = new NpgsqlCommand(DB_Functions.InsertProbabilities.ToDescription());
                ProbabilitiesCommand.Parameters.AddWithValue("is_deleted", false);
                var probabilities_id = insert(ProbabilitiesCommand);
                queue.Enqueue(SetRollback(probabilities_id, Tables.Probabilities, TransactionTypes.Insert));

                foreach (var prob in entity)
                {
                    var probCommand = new NpgsqlCommand(DB_Functions.InsertProbability.ToDescription());
                    probCommand.Parameters.AddWithValue("fk_probabilities_id", probabilities_id);
                    if (prob.OddsType != null)
                    {
                        probCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Integer, prob.OddsType);
                    }
                    else
                    {
                        probCommand.Parameters.AddWithValue("odds_type", NpgsqlDbType.Integer, DBNull.Value);
                    }
                    var ret = insertOddsProbabilities(prob.OddsProbabilities);
                    probCommand.Parameters.AddWithValue("fk_odds_probabilities_id", ret.id);
                    var objId = insert(probCommand);
                    queue.Enqueue(SetRollback(objId, Tables.Probability, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, probabilities_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        public long insertPitcher(PitcherEntity entity)
        {
            var Command = new NpgsqlCommand(DB_Functions.InsertPitcher.ToDescription());
            try
            {
                if (!string.IsNullOrEmpty(entity.Hand.ToString()))
                {
                    Command.Parameters.AddWithValue("pitcher_hand", entity.Hand);
                }
                else
                {
                    Command.Parameters.AddWithValue("pitcher_hand", DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Name))
                {
                    Command.Parameters.AddWithValue("pitcher_name", entity.Name);
                }
                else
                {
                    Command.Parameters.AddWithValue("pitcher_name", DBNull.Value);
                }
                return insert(Command);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// Insert Tournament 
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertTournament(TournamentEntity entity)
        {
            var queue = new Queue<Rollback>();
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertTournament.ToDescription());
            try
            {
                if (entity.Id != null)
                {
                    ObjCommand.Parameters.AddWithValue("tournamentid", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("tournamentid", NpgsqlDbType.Bigint, DBNull.Value);
                }
                ObjCommand.Parameters.AddWithValue("fk_id_name_tuple_id", NpgsqlDbType.Bigint, DBNull.Value);
                if (entity.Texts != null)
                {
                    var id = insertTexts(entity.Texts);
                    if (id == -1)
                    {
                        ObjCommand.Parameters.AddWithValue("fx_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("fx_texts_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.Texts, TransactionTypes.Insert));
                    }
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("fx_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.SuperTournament != null)
                {
                    var id = insertIdNameTuple(entity.SuperTournament);
                    if (id == -1)
                    {
                        ObjCommand.Parameters.AddWithValue("super_tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("super_tournament_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.Id_Name_Tuple, TransactionTypes.Insert));
                    }
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("super_tournament_id", DBNull.Value);
                }
                var RetId = insert(ObjCommand);
                if (RetId >0)
                {
                    return new ReturnQueueLong(queue, RetId);
                }
                else
                {
                    return new ReturnQueueLong(queue, -1);
                }
               
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert ID Name Tuple
        /// </summary>
        /// <param name="tuple"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertIdNameTuple(IdNameTuple tuple)
        {
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertIdNameTuple.ToDescription());
            try
            {
                if (tuple.Id != null)
                {
                    ObjCommand.Parameters.AddWithValue("team_tournament_id", NpgsqlDbType.Bigint, tuple.Id);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("team_tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (tuple.Name != null)
                {
                    var id = insertLocalizedString(tuple.Name);
                    if (id > 0)
                    {
                        ObjCommand.Parameters.AddWithValue("name_localized_id", NpgsqlDbType.Bigint, id);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("name_localized_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("name_localized_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (tuple.UniqueId != null)
                {
                    ObjCommand.Parameters.AddWithValue("unique_id", NpgsqlDbType.Bigint, tuple.UniqueId);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("unique_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return insert(ObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                throw;
            }
        }

        public ReturnQueueLong insertTransaltions(LocalizedString loc, long LocalizationId)
        {
            var queue = new Queue<Rollback>();
            try
            {
                foreach (var localization in loc.AvailableTranslationLanguages)
                {
                    var ObjCommand = new NpgsqlCommand(DB_Functions.InsertTranslations.ToDescription());
                    ObjCommand.Parameters.AddWithValue("p_code", NpgsqlDbType.Text, localization);
                    ObjCommand.Parameters.AddWithValue("p_translations", NpgsqlDbType.Text, loc.GetTranslation(localization));
                    ObjCommand.Parameters.AddWithValue("p_fk_localized_string_id", NpgsqlDbType.Bigint, LocalizationId);
                    var translation_id = insert(ObjCommand);
                    queue.Enqueue(SetRollback(translation_id, Tables.Translations, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, 0);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        public long insertLocalizedString(LocalizedString loc)
        {
            if (loc.AvailableTranslationLanguages != null && loc.AvailableTranslationLanguages.Length > 0)
            {
                var ObjCommand = new NpgsqlCommand(DB_Functions.InsertLocalizedString.ToDescription());
                try
                {
                    if (!string.IsNullOrEmpty(loc.International))
                    {
                        ObjCommand.Parameters.AddWithValue("international", loc.International);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("international", DBNull.Value);
                    }

                    var id = insertAvailableTranslations(loc);
                    ObjCommand.Parameters.AddWithValue("fk_available_translation_languages", id);

                    return insert(ObjCommand);
                }

                catch
                (Exception ex)
                {
                    Logg.logger.Fatal(ex.Message);
                    return -1;
                }
            }
            else
            {
                return 0;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="languages"></param>
        /// <param name="availableTableIds"></param>
        public ReturnQueueLong insertLanguages(string[] languages, long availableTableIds)
        {
            var queue = new Queue<Rollback>();
            try
            {
                if (languages.Length > 0)
                {
                    foreach (var lang in languages)
                    {
                        var ObjCommand = new NpgsqlCommand(DB_Functions.InsertLanguages.ToDescription());
                        ObjCommand.Parameters.AddWithValue("code", lang);
                        ObjCommand.Parameters.AddWithValue("description", NpgsqlDbType.Text, DBNull.Value);
                        ObjCommand.Parameters.AddWithValue("fk_available_translations", availableTableIds);
                        var id = insert(ObjCommand);
                        ObjCommand.Dispose();
                        queue.Enqueue(SetRollback(id, Tables.Languages, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, 0);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }
        public long insertAvailableTranslations(LocalizedString languages)
        {
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertAvailableTrasnlationLanguages.ToDescription());
            try
            {
                ObjCommand.Parameters.AddWithValue("fk_languages_id", DBNull.Value);
                var id = insert(ObjCommand);
                var ret = insertTransaltions(languages, id);
                //insertLanguages(languages, id);
                return id;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// Insert outright Results
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        public ReturnQueueLong insertOutrightResults(List<OutrightResultEntity> entities)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertOutrightResults.ToDescription());
            try
            {
                command.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Boolean, false);
                var results_id = insert(command);
                foreach (var entity in entities)
                {
                    queue.Enqueue(SetRollback(insertOutrightResult(entity, results_id), Tables.OutrightResult, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, results_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Single Outright Result
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private long insertOutrightResult(OutrightResultEntity entity, long ResultsId)
        {
            var command = new NpgsqlCommand(DB_Functions.InsertOutrightResult.ToDescription());
            try
            {
                if (entity.DeadHeatFactor != null)
                {
                    command.Parameters.AddWithValue("dead_heat_factor", NpgsqlDbType.Double, entity.DeadHeatFactor);
                }
                else
                {
                    command.Parameters.AddWithValue("dead_heat_factor", NpgsqlDbType.Double, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Id))
                {
                    command.Parameters.AddWithValue("outright_result_id", NpgsqlDbType.Text, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("outright_result_id", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Value))
                {
                    command.Parameters.AddWithValue("value", NpgsqlDbType.Text, entity.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (ResultsId != null && ResultsId > 0)
                {
                    command.Parameters.AddWithValue("fk_outright_results_id", NpgsqlDbType.Bigint, ResultsId);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_outright_results_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return insert(command);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// insert Goals 
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertGoals(GoalsEntity entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                ///Insert into the main Messages table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertGoals.ToDescription());
                if (entity.Doubtful != null)
                {
                    adObjCommand.Parameters.AddWithValue("doubtful", entity.Doubtful);
                }
                else
                {
                    adObjCommand.Parameters.AddWithValue("doubtful", NpgsqlDbType.Boolean, DBNull.Value);
                }
                adObjCommand.Parameters.AddWithValue("fk_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                var goals_id = insert(adObjCommand);

                /// Now insert the detailed message to message table
                foreach (var goal in entity.Goals)
                {
                    var ObjCommand = new NpgsqlCommand(DB_Functions.InsertGoal.ToDescription());
                    if (goal.Id != null)
                    {
                        ObjCommand.Parameters.AddWithValue("goal_id", goal.Id);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("goal_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (goal.Player != null)
                    {
                        var ret = insertPlayer(goal.Player, -1);
                        ObjCommand.Parameters.AddWithValue("fk_player_id", ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Tables.Player, TransactionTypes.Insert));
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (goal.Score != null)
                    {
                        var id = insertHomeAway(goal.Score);
                        ObjCommand.Parameters.AddWithValue("score", id);
                        queue.Enqueue(SetRollback(id, Tables.HomeAway, TransactionTypes.Insert));
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("score", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (goal.ScoringTeam != null)
                    {
                        var team = selectEnumValue(MasterEnum.Team.ToDescription(), goal.ScoringTeam.ToDescription());
                        ObjCommand.Parameters.AddWithValue("fk_team_id", team);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("fk_team_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(goal.Time))
                    {
                        ObjCommand.Parameters.AddWithValue("time", goal.Time);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("time", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(goal.Type))
                    {
                        ObjCommand.Parameters.AddWithValue("type", goal.Type);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                    }
                    ObjCommand.Parameters.AddWithValue("fx_goals_id", goals_id);
                    insert(ObjCommand);
                }
                return new ReturnQueueLong(queue, goals_id);
            }
            catch (Exception)
            {
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Date Info
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertDateinfo(DateInfoEntity entity)
        {
            var queue = new Queue<Rollback>();
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertDateinfo.ToDescription());
            ObjCommand.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
            try
            {
                if (entity.Comment != null)
                {
                    var id = insertComment(entity.Comment);
                    if (id == -1)
                    {
                        ObjCommand.Parameters.AddWithValue("fk_comment_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("fk_comment_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.Comment, TransactionTypes.Insert));
                    }
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("fk_comment_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.ConfirmedMatchStart != null)
                {
                    ObjCommand.Parameters.AddWithValue("confirmed_match_start", NpgsqlDbType.Timestamp, entity.ConfirmedMatchStart);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("confirmed_match_start", NpgsqlDbType.Timestamp, DBNull.Value);
                }
                if (entity.Info != null)
                {
                    var id = insertTypeValueTuple(entity.Info);
                    if (id == -1)
                    {
                        ObjCommand.Parameters.AddWithValue("fk_info_typevaluetuple", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("fk_info_typevaluetuple", NpgsqlDbType.Bigint, entity.Info);
                        queue.Enqueue(SetRollback(id, Tables.TypeValueTuple, TransactionTypes.Insert));
                    }
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("fk_info_typevaluetuple", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.MatchDate != null)
                {
                    ObjCommand.Parameters.AddWithValue("match_date", NpgsqlDbType.Timestamp, entity.MatchDate);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("match_date", NpgsqlDbType.Timestamp, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(ObjCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Type Value Tuple using type, value  only.
        /// </summary>
        /// <param name="tuple"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertTypeValueTuple(TypeValueTuple tuple)
        {
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertTypeValueTuple.ToDescription());
            try
            {

                if (!string.IsNullOrEmpty(tuple.Value))
                {
                    ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, tuple.Value);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(tuple.Type))
                {
                    ObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, tuple.Type);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                }

                return insert(ObjCommand);

            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Insert Comment
        /// </summary>
        /// <param name="comment"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertComment(List<CommentEntity> comment)
        {
            var queue = new Queue<Rollback>();
            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertComment.ToDescription());
            try
            {
                foreach (var com in comment)
                {
                    if (!string.IsNullOrEmpty(com.Language))
                    {
                        ObjCommand.Parameters.AddWithValue("language", NpgsqlDbType.Text, com.Language);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("language", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (!string.IsNullOrEmpty(com.Value))
                    {
                        ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, com.Value);
                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (com.Texts != null)
                    {
                        var id = insertTexts(com.Texts);
                        ObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, id);

                    }
                    else
                    {
                        ObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    ObjCommand.Parameters.AddWithValue("fk_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return insert(ObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// Comment
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public long insertComment(CommentEntity entity)
        {

            var ObjCommand = new NpgsqlCommand(DB_Functions.InsertComment.ToDescription());
            try
            {

                if (!string.IsNullOrEmpty(entity.Language))
                {
                    ObjCommand.Parameters.AddWithValue("language", NpgsqlDbType.Text, entity.Language);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("language", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Value))
                {
                    ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, entity.Value);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Texts != null)
                {
                    var id = insertTexts(entity.Texts);
                    ObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, id);
                }
                else
                {
                    ObjCommand.Parameters.AddWithValue("fk_texts_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                ObjCommand.Parameters.AddWithValue("fk_match_id", NpgsqlDbType.Bigint, DBNull.Value);

                return insert(ObjCommand);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                throw;
            }
        }

        /// <summary>
        /// Insert cards with grouping
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertCards(CardsEntity entity)
        {
            var queue = new Queue<Rollback>();
            try
            {
                ///Insert into the main Cards table (1 => ∞) first
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertCards.ToDescription().ToString());
                adObjCommand.Parameters.AddWithValue("doubtful", NpgsqlDbType.Boolean, entity.Doubtful);
                adObjCommand.Parameters.AddWithValue("fk_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                var cards_id = insert(adObjCommand);

                if (cards_id > 0)
                {
                    /// Now insert the detailed dictionaries to dictionary table
                    foreach (var card in entity.Cards)
                    {
                        var cardObjCommand =
                           new NpgsqlCommand(DB_Functions.InsertCard.ToDescription());

                        if (card.Player.SuperId != null)
                        {
                            cardObjCommand.Parameters.AddWithValue("affected_player", NpgsqlDbType.Bigint,card.Player.SuperId);
                        }
                        else
                        {
                            cardObjCommand.Parameters.AddWithValue("affected_player", NpgsqlDbType.Bigint,DBNull.Value);
                        }
                        cardObjCommand.Parameters.AddWithValue("affected_team", NpgsqlDbType.Text, DBNull.Value);
                        if (card.Id != null)
                        {
                            cardObjCommand.Parameters.AddWithValue("card_id", long.Parse(card.Id.ToString()));
                        }
                        else
                        {
                            cardObjCommand.Parameters.AddWithValue("card_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        cardObjCommand.Parameters.AddWithValue("value", "");
                        if (card.Time != null)
                        {
                            cardObjCommand.Parameters.AddWithValue("time", card.Time.ToString());
                        }
                        else
                        {
                            cardObjCommand.Parameters.AddWithValue("time", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (card.Type != null)
                        {
                            cardObjCommand.Parameters.AddWithValue("type", card.Type.ToString());
                        }
                        else
                        {
                            cardObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (card.Player != null)
                        {
                            var id = insertPlayer(card.Player, -1);
                            cardObjCommand.Parameters.AddWithValue("fk_player_id", id);
                        }
                        else
                        {
                            cardObjCommand.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        if (cards_id != null)
                        {
                            cardObjCommand.Parameters.AddWithValue("fk_cards_id", long.Parse(cards_id.ToString()));
                        }
                        else
                        {
                            cardObjCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }

                        queue.Enqueue(SetRollback(insert(cardObjCommand), Tables.Card, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, cards_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert cards with detailed cards.
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertCards(ScoreCardSummaryEventArgs entity)
        {
            var queue = new Queue<Rollback>();

            ///Insert into the main Cards table (1 => ∞) first
            /// 
            if (entity.ScoreCardSummary.CardsByTime.Count > 0)
            {
                var adObjCommand = new NpgsqlCommand(DB_Functions.InsertCards.ToDescription().ToString());
                adObjCommand.Parameters.AddWithValue("doubtful", NpgsqlDbType.Boolean, DBNull.Value);
                adObjCommand.Parameters.AddWithValue("fk_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                try
                {
                    var cards_id = insert(adObjCommand);

                    if (cards_id > 0)
                    {

                        /// Now insert the detailed dictionaries to dictionary table
                        foreach (var card in entity.ScoreCardSummary.CardsByTime)
                        {
                            var cardObjCommand = new NpgsqlCommand(DB_Functions.InsertCard.ToDescription());

                            if (!string.IsNullOrEmpty(card.AffectedPlayer))
                            {
                                cardObjCommand.Parameters.AddWithValue("affected_player", NpgsqlDbType.Text,
                                    card.AffectedPlayer);
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("affected_player", NpgsqlDbType.Text,
                                    DBNull.Value);
                            }

                            if (card.AffectedTeam != null)
                            {
                                cardObjCommand.Parameters.AddWithValue("affected_team", NpgsqlDbType.Text,
                                    card.AffectedTeam.ToString());
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("affected_team", NpgsqlDbType.Text, DBNull.Value);
                            }
                            if (card.Id != null)
                            {
                                cardObjCommand.Parameters.AddWithValue("card_id", NpgsqlDbType.Bigint,
                                    long.Parse(card.Id.ToString()));
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("card_id", NpgsqlDbType.Bigint, DBNull.Value);
                            }
                            cardObjCommand.Parameters.AddWithValue("value", NpgsqlDbType.Text, "");
                            if (card.Time != null)
                            {
                                cardObjCommand.Parameters.AddWithValue("time", NpgsqlDbType.Text, card.Time.ToString());
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("time", NpgsqlDbType.Text, DBNull.Value);
                            }
                            if (card.Type != null)
                            {
                                cardObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, card.Type.ToString());
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                            }
                            if (card.PlayerId != null)
                            {
                                cardObjCommand.Parameters.AddWithValue("fk_player_id",
                                    long.Parse(card.PlayerId.ToString()));
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("fk_player_id", NpgsqlDbType.Bigint, DBNull.Value);
                            }
                            if (cards_id != null)
                            {
                                cardObjCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint,
                                    long.Parse(cards_id.ToString()));
                            }
                            else
                            {
                                cardObjCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint, DBNull.Value);
                            }
                            queue.Enqueue(SetRollback(insert(cardObjCommand), Tables.Card,
                                TransactionTypes.Insert));
                        }
                    }
                    return new ReturnQueueLong(queue, cards_id);
                }
                catch (Exception ex)
                {
                    Logg.logger.Fatal(ex);
                    return new ReturnQueueLong(queue, -1);
                }
            }
            else
            {
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Messages
        /// </summary>
        /// <param name="messages"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertMessages(string[] messages)
        {
            var queue = new Queue<Rollback>();
            ///Insert into the main Messages table (1 => ∞) first
            var adObjCommand = new NpgsqlCommand(DB_Functions.InsertMessages.ToDescription());
            adObjCommand.Parameters.AddWithValue("is_deleted", false);
            try
            {
                var messages_id = insert(adObjCommand);

                /// Now insert the detailed message to message table
                foreach (var message in messages)
                {
                    var messageObjCommand = new NpgsqlCommand(DB_Functions.InsertMessage.ToDescription());
                    messageObjCommand.Parameters.AddWithValue("message", message);
                    messageObjCommand.Parameters.AddWithValue("fk_messages_id", messages_id);
                    queue.Enqueue(SetRollback(insert(messageObjCommand), Tables.Message, TransactionTypes.Insert));
                }
                return new ReturnQueueLong(queue, messages_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Scores
        /// </summary>
        /// <param name="scores"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertScores(List<TypeValueTuple> scores)
        {
            var queue = new Queue<Rollback>();
            var adCommand = new NpgsqlCommand(DB_Functions.InsertScores.ToDescription());
            adCommand.Parameters.AddWithValue("is_deleted", false);
            try
            {
                var scores_id = insert(adCommand);
                if (scores_id > 0)
                {
                    foreach (var score in scores)
                    {
                        var command = new NpgsqlCommand(DB_Functions.InsertTypeValueTuple.ToDescription());
                        if (!string.IsNullOrEmpty(score.Value))
                        {
                            command.Parameters.AddWithValue("value", NpgsqlDbType.Text, score.Value);
                        }
                        else
                        {
                            command.Parameters.AddWithValue("value", NpgsqlDbType.Text, DBNull.Value);
                        }
                        if (!string.IsNullOrEmpty(score.Type))
                        {
                            command.Parameters.AddWithValue("type", NpgsqlDbType.Text, score.Type);
                        }
                        else
                        {
                            command.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                        }
                        command.Parameters.AddWithValue("fk_id", scores_id);
                        queue.Enqueue(SetRollback(insert(command), Tables.TypeValueTuple, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, scores_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Scores Info 
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong inserScoresInfo(ScoresInfoEntity entity)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertScoresInfo.ToDescription());
            try
            {
                if (entity.DecidedByFa != null)
                {
                    command.Parameters.AddWithValue("decided_by_fa", NpgsqlDbType.Boolean, entity.DecidedByFa);
                }
                else
                {
                    command.Parameters.AddWithValue("decided_by_fa", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Scores != null)
                {
                    var ret = insertScores(entity.Scores);
                    long scores_id = -1;
                    if (ret != null)
                    {
                        queue.Enqueue(ret.queue.Dequeue());
                        scores_id = ret.id;
                    }
                    command.Parameters.AddWithValue("fk_scores_id", NpgsqlDbType.Bigint, scores_id);
                }
                else { command.Parameters.AddWithValue("fk_scores_id", NpgsqlDbType.Bigint, DBNull.Value); }

                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert result.
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertResult(ResultEntity entity)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertResult.ToDescription());
            try
            {
                if (entity.Comment != null)
                {
                    var comment_id = insertComment(entity.Comment);
                    queue.Enqueue(SetRollback(comment_id, Tables.Comment, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_comment_id", NpgsqlDbType.Bigint, comment_id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_comment_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.ScoresInfo != null)
                {
                    var ret = inserScoresInfo(entity.ScoresInfo);
                    if (ret != null)
                    {
                        for (var i = 0; i < ret.queue.Count; i++)
                        {
                            queue.Enqueue(ret.queue.Dequeue());
                        }
                        command.Parameters.AddWithValue("fk_scores_info_id", NpgsqlDbType.Bigint, ret.id);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_scores_info_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_scores_info_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.WinningOutcome != null)
                {
                    var winning_id = insertWinningOutcome(entity.WinningOutcome);
                    queue.Enqueue(SetRollback(winning_id, Tables.Winning_Outcome, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_winning_outcome_id", NpgsqlDbType.Bigint, winning_id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_winning_outcome_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert winning is the winning team of a tournament.
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns> 
        public long insertWinningOutcome(WinningOutcomeEntity entity)
        {
            var command = new NpgsqlCommand(DB_Functions.InsertWinningOutcome.ToDescription());
            try
            {
                if (!string.IsNullOrEmpty(entity.Outcome))
                {
                    command.Parameters.AddWithValue("outcome", entity.Outcome);
                }
                else
                {
                    command.Parameters.AddWithValue("outcome", DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Reason))
                {
                    command.Parameters.AddWithValue("reason", entity.Reason);
                }
                else
                {
                    command.Parameters.AddWithValue("reason", DBNull.Value);
                }
                return insert(command);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
        }

        /// <summary>
        /// Insert Sport
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// 
        public ReturnQueueLong insertSport(SportEntity entity)
        {
            var queue = new Queue<Rollback>();
            var SportCommand = new NpgsqlCommand(DB_Functions.InsertSport.ToDescription());
            try
            {
                if (entity.Id != null)
                {
                    SportCommand.Parameters.AddWithValue("sport_id", NpgsqlDbType.Integer, entity.Id);
                }
                else
                {
                    SportCommand.Parameters.AddWithValue("sport_id", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.Texts != null)
                {
                    var id = insertTexts(entity.Texts);
                    queue.Enqueue(SetRollback(id, Tables.Texts, TransactionTypes.Insert));
                    SportCommand.Parameters.AddWithValue("fk_texts_id", id);
                }
                return new ReturnQueueLong(queue, insert(SportCommand));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }


        /// <summary>
        /// Insert Match Roles
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// 
        public ReturnQueueLong insertMatchRoles(List<MatchRole> entity)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertMatchRoles.ToDescription());
            var matchroles_id = insert(command);
            try
            {
                foreach (var role in entity)
                {
                    var com = new NpgsqlCommand(DB_Functions.InsertMatchRole.ToDescription());
                    if (role.Description != null)
                    {
                        com.Parameters.AddWithValue("description", NpgsqlDbType.Text, role.Description);
                    }
                    else
                    {
                        com.Parameters.AddWithValue("description", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (role.Id != null)
                    {
                        com.Parameters.AddWithValue("match_role_id", NpgsqlDbType.Integer, role.Id);
                    }
                    else
                    {
                        com.Parameters.AddWithValue("match_role_id", NpgsqlDbType.Integer, DBNull.Value);
                    }
                    com.Parameters.AddWithValue("fk_match_roles_id", NpgsqlDbType.Bigint, matchroles_id);
                    var id = insert(com);
                    if (id != null && id > -1)
                    {
                        queue.Enqueue(SetRollback(id, Tables.MatchRole, TransactionTypes.Insert));
                    }
                }
                return new ReturnQueueLong(queue, matchroles_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert 
        /// </summary>
        /// <param name="Lineupentity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// 
        /// <returns>ReturnQueueLong</returns>



        #region Live

        /// <summary>
        /// Bet Clear Rollback Header Insert
        /// </summary>
        /// <param name="betclearrollback"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(BetClearRollback betclearrollback)
        {
            var entity = betclearrollback.EventHeader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Outright Header
        /// </summary>
        /// <param name="outrightheader"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(OutrightHeader outrightheader)
        {
            var entity = outrightheader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }


        /// <summary>
        /// Event Header
        /// </summary>
        /// <param name="eventheader"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(EventHeader eventheader)
        {
            var entity = eventheader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }


        /// <summary>
        /// Bet Cancel
        /// </summary>
        /// <param name="BetCancel"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(Sportradar.SDK.FeedProviders.LiveOdds.Common.BetCancel betcancel)
        {
            var entity = betcancel.EventHeader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Odds Change Cancel
        /// </summary>
        /// <param name="OddsChange"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(OddsChange oddschange)
        {
            var entity = oddschange.EventHeader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Bet Clear Header Insert
        /// </summary>
        /// <param name="BetClear"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(BetClear betclear)
        {
            var entity = betclear.EventHeader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Bet Start Header Insert
        /// </summary>
        /// <param name="betstart"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(BetStart betstart)
        {
            var entity = betstart.EventHeader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Bet Stop Header Insert
        /// </summary>
        /// <param name="betstop"></param>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventHeader(BetStop betstop)
        {
            var entity = betstop.EventHeader;
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InserEventHeader.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.BetStatus.Value.ToString()))
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, entity.BetStatus.Value.ToString());
                }
                else
                {
                    command.Parameters.AddWithValue("bet_status", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Message != null)
                {
                    var ret = insertMessages(entity.Message);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Tables.Messages, TransactionTypes.Insert));
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Msgnr != null)
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, entity.Msgnr);
                }
                else
                {
                    command.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Status != null)
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, entity.Status);
                }
                else
                {
                    command.Parameters.AddWithValue("status", NpgsqlDbType.Text, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex);
                return new ReturnQueueLong(queue, -1);
            }
        }

        /// <summary>
        /// Insert Event Odds Field for event odds.
        /// </summary>
        /// <param name="entity"></param>
        /// Returns custom type Return Queue Long;        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback        /// Long: is the main inserted row id        /// </returns>
        public ReturnQueueLong insertEventOddsField(EventOddsField entity, long fk_event_odds_fields_id)
        {
            var queue = new Queue<Rollback>();

            var command = new NpgsqlCommand(DB_Functions.InsertEventOddsField.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Outcome != null)
                {
                    command.Parameters.AddWithValue("outcome", NpgsqlDbType.Boolean, entity.Outcome);
                }
                else
                {
                    command.Parameters.AddWithValue("outcome", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.PlayerId != null)
                {
                    command.Parameters.AddWithValue("player_id", NpgsqlDbType.Bigint, entity.PlayerId);
                }
                else
                {
                    command.Parameters.AddWithValue("player_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Probability != null)
                {
                    command.Parameters.AddWithValue("probability", NpgsqlDbType.Double, entity.Probability);
                }
                else
                {
                    command.Parameters.AddWithValue("probability", NpgsqlDbType.Double, DBNull.Value);
                }
                if (entity.Type != null)
                {
                    var id = insertLocalizedString(entity.Type);
                    if (id < 1)
                    {
                        command.Parameters.AddWithValue("fk_localized_string_type", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        queue.Enqueue(SetRollback(id, Tables.LocalizedString, TransactionTypes.Insert));
                        command.Parameters.AddWithValue("fk_localized_string_type", NpgsqlDbType.Bigint, id);
                    }

                }
                else
                {
                    command.Parameters.AddWithValue("fk_localized_string_type", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.TypeId != null)
                {
                    command.Parameters.AddWithValue("type_id", NpgsqlDbType.Integer, entity.TypeId);
                }
                else
                {
                    command.Parameters.AddWithValue("type_id", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.Value != null)
                {
                    command.Parameters.AddWithValue("value", NpgsqlDbType.Numeric, entity.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("value", NpgsqlDbType.Numeric, DBNull.Value);
                }
                if (entity.ViewIndex != null)
                {
                    command.Parameters.AddWithValue("view_index", NpgsqlDbType.Integer, entity.ViewIndex);
                }
                else
                {
                    command.Parameters.AddWithValue("view_index", NpgsqlDbType.Integer, DBNull.Value);
                }
                if (entity.VoidFactor != null)
                {
                    command.Parameters.AddWithValue("void_factor", NpgsqlDbType.Double, entity.VoidFactor);
                }
                else
                {
                    command.Parameters.AddWithValue("void_factor", NpgsqlDbType.Double, DBNull.Value);
                }
                if (fk_event_odds_fields_id != null && fk_event_odds_fields_id > 0)
                {
                    command.Parameters.AddWithValue("fk_event_odds_fields_id", NpgsqlDbType.Bigint, fk_event_odds_fields_id);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_event_odds_fields_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                return new ReturnQueueLong(queue, insert(command));
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        public ReturnQueueLong insertEventOdds(EventOdds entity, long? ManyId)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertEventOdds.ToDescription());
            try
            {
                if (entity.Active != null)
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, entity.Active);
                }
                else
                {
                    command.Parameters.AddWithValue("active", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Changed != null)
                {
                    command.Parameters.AddWithValue("changed", NpgsqlDbType.Boolean, entity.Changed);
                }
                else
                {
                    command.Parameters.AddWithValue("changed", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Combination != null)
                {
                    command.Parameters.AddWithValue("combination", NpgsqlDbType.Bigint, entity.Combination);
                }
                else
                {
                    command.Parameters.AddWithValue("combination", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.ForTheRest != null)
                {
                    command.Parameters.AddWithValue("for_the_rest", NpgsqlDbType.Text, entity.ForTheRest);
                }
                else
                {
                    command.Parameters.AddWithValue("for_the_rest", NpgsqlDbType.Text, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Freetext))
                {
                    command.Parameters.AddWithValue("free_text", NpgsqlDbType.Text, entity.Freetext);
                }
                else
                {
                    command.Parameters.AddWithValue("free_text", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.OddsFields != null)
                {
                    var ret = insertEventOddsFields(entity.OddsFields);
                    if (ret.id == -1)
                    {
                        command.Parameters.AddWithValue("fk_event_odds_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_event_odds_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_event_odds_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.MostBalanced != null)
                {
                    command.Parameters.AddWithValue("most_balanced", NpgsqlDbType.Boolean, entity.MostBalanced);
                }
                else
                {
                    command.Parameters.AddWithValue("most_balanced", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (entity.Name != null)
                {
                    var id = insertLocalizedString(entity.Name);
                    if (id > 0)
                    {
                        command.Parameters.AddWithValue("fk_localized_string_id", NpgsqlDbType.Bigint, id);
                        queue.Enqueue(SetRollback(id, Tables.LocalizedString, TransactionTypes.Insert));
                    }
                    else
                    {
                        command.Parameters.AddWithValue("fk_localized_string_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    command.Parameters.AddWithValue("fk_localized_string_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    command.Parameters.AddWithValue("event_odds_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    command.Parameters.AddWithValue("event_odds_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.SpecialOddsValue))
                {
                    command.Parameters.AddWithValue("special_odds_value", NpgsqlDbType.Text, entity.SpecialOddsValue);
                }
                else
                {
                    command.Parameters.AddWithValue("special_odds_value", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.SubType != null)
                {
                    command.Parameters.AddWithValue("sub_type", NpgsqlDbType.Bigint, entity.SubType);
                }
                else
                {
                    command.Parameters.AddWithValue("sub_type", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Type != null)
                {
                    command.Parameters.AddWithValue("type", NpgsqlDbType.Text, entity.Type.ToDescription());
                }
                else
                {
                    command.Parameters.AddWithValue("type", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.TypeId != null)
                {
                    command.Parameters.AddWithValue("type_id", NpgsqlDbType.Bigint, entity.TypeId);
                }
                else
                {
                    command.Parameters.AddWithValue("type_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (ManyId != null && ManyId > 0)
                {
                    command.Parameters.AddWithValue("fk_event_odds_many_id", NpgsqlDbType.Bigint, ManyId);
                }
                else
                {
                    command.Parameters.AddWithValue("fk_event_odds_many_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                var ids = insert(command);
                return new ReturnQueueLong(queue, ids);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }

        }

        /// <summary>
        /// Insert Event Odds Fields: this is where you insert the dictionary that contains Key,value and the value is of type EventOddsField
        /// </summary>
        /// <param name="entity"></param>
        /// <returns>
        /// Returns custom type Return Queue Long;
        /// Queue: is the sum of other inserts " if applied " to add to the mother queue in case of rollback
        /// Long: is the main inserted row id
        /// </returns>
        public ReturnQueueLong insertEventOddsFields(IDictionary<string, EventOddsField> entity)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertEventOddsFieldsDictionary.ToDescription());

            try
            {
                command.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Boolean, false);
                var dictionaries_id = insert(command);
                // queue.Enqueue(SetRollback(dictionaries_id, Globals.Tables.EventOddsFieldsDictionary, Globals.TransactionTypes.Insert));

                foreach (var e in entity)
                {
                    var adCommand = new NpgsqlCommand(DB_Functions.InsertEventOddsFields.ToDescription());
                    if (e.Key != null)
                    {

                        adCommand.Parameters.AddWithValue("local_key", NpgsqlDbType.Text, e.Key);
                    }
                    else
                    {
                        adCommand.Parameters.AddWithValue("local_key", NpgsqlDbType.Text, DBNull.Value);
                    }
                    if (e.Value != null)
                    {
                        if (dictionaries_id == -1)
                        {
                            adCommand.Parameters.AddWithValue("fk_event_odds_field_dictionary_id", NpgsqlDbType.Bigint, DBNull.Value);
                        }
                        else
                        {
                            adCommand.Parameters.AddWithValue("fk_event_odds_field_dictionary_id", NpgsqlDbType.Bigint, dictionaries_id);
                        }
                        var id = insert(adCommand);
                        if (id != -1)
                        {
                            var ret = insertEventOddsField(e.Value, id);
                            if (ret.id != -1)
                            {
                                queue.Enqueue(SetRollback(id, Tables.EventOddsFields, TransactionTypes.Insert));
                                queue = CloneRollbackQueue(queue, ret.queue);
                            }

                        }
                    }
                    else
                    {
                        adCommand.Parameters.AddWithValue("fk_event_odds_field_dictionary_id", NpgsqlDbType.Bigint, DBNull.Value);
                        queue.Enqueue(SetRollback(insert(adCommand), Tables.EventOddsFields, TransactionTypes.Insert));
                    }

                }
                return new ReturnQueueLong(queue, dictionaries_id);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }
        }

        public ReturnQueueLong insertEventOddsMany(List<EventOdds> entities)
        {
            var queue = new Queue<Rollback>();
            var command = new NpgsqlCommand(DB_Functions.InsertEventOddsMany.ToDescription());
            try
            {
                command.Parameters.AddWithValue("is_deleted", NpgsqlDbType.Boolean, false);
                var id = insert(command);
                if (id != -1)
                {
                    foreach (var entity in entities)
                    {
                        var ret = insertEventOdds(entity, id);
                        if (ret.id != -1)
                        {
                            queue.Enqueue(SetRollback(ret.id, Tables.EventOdds, TransactionTypes.Insert));
                            queue = CloneRollbackQueue(queue, ret.queue);
                        }
                        else
                        {
                            return new ReturnQueueLong(queue, -1);
                        }
                    }
                    return new ReturnQueueLong(queue, id);
                }
                return new ReturnQueueLong(queue, -1);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return new ReturnQueueLong(queue, -1);
            }


        }

        #endregion

        /// <summary>
        /// This function sets the Roll Back object and the calling function sets the queue in case of a roll back
        /// </summary>
        /// <param name="RowId"></param>
        /// <param name="Table"></param>
        /// <param name="Transaction"></param>
        /// <returns>Globals.Rollback</returns>
        public Rollback SetRollback(long RowId, Tables Table, TransactionTypes Transaction)
        {
            var rollbackObject = new Rollback();
            try
            {
                rollbackObject.RowId = RowId;
                rollbackObject.TableId = (int)Table;
                rollbackObject.TransactionType = (int)Transaction;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return null;
            }
            return rollbackObject;
        }
        public void RollBack(List<Rollback> rolls)
        {
            // Get call stack
            StackTrace stackTrace = new StackTrace();

            // Get calling method name
            Console.WriteLine(stackTrace.GetFrame(1).GetMethod().Name);
            try
            {
                foreach (var roll in rolls)
                {
                    var adObjCommand = new NpgsqlCommand(DB_Functions.Rollback.ToDescription());
                    adObjCommand.Parameters.AddWithValue("table_id", roll.TableId);
                    adObjCommand.Parameters.AddWithValue("row_id", roll.RowId);
                    adObjCommand.Parameters.AddWithValue("tran_type", roll.TransactionType);
                    update(adObjCommand);
                }
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
            }
            finally
            {

            }
        }
        public void connection()
        {
            try
            {
                if (con == null)
                {

                    var connectionBuilder = new NpgsqlConnectionStringBuilder();
                    connectionBuilder.Host = config.AppSettings.Get("DB_Host");
                    connectionBuilder.Port = int.Parse(config.AppSettings.Get("DB_Port"));
                    connectionBuilder.Database = config.AppSettings.Get("DB_Database");
                    connectionBuilder.Username = config.AppSettings.Get("DB_Username");
                    connectionBuilder.Password = config.AppSettings.Get("DB_Password");
                    connectionBuilder.Timeout = 20;
                    connectionBuilder.Pooling = true;
                    connectionBuilder.CommandTimeout = 20;
                    con = new NpgsqlConnection(connectionBuilder.ConnectionString);
                }

            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
            }

        }
        public long insert(NpgsqlCommand objCommand)
        {
            long errorNumber = -1;
            objCommand.CommandType = CommandType.StoredProcedure;
            try
            {
                connection();
                
                objCommand.Connection = con;
                //objCommand.CommandTimeout = 5;
                
                objCommand.Connection.Open();
                var result = objCommand.ExecuteScalar();
                long val = 0;
                if (result != null && long.TryParse(result.ToString(), out val))
                {
                    if (val > 0)
                    {
                        return val;
                    }
                    else
                    {
                        errorNumber = val;
                        throw new DataException();
                    }
                }
                return -1;
            }
            catch (Exception ex)
            {
                objCommand.Connection.Close();
                StackTrace trace = new StackTrace(true);
                var frame = trace.GetFrame(1);
                var altMessage = "  Error#: " + errorNumber.ToString() + "  METHOD: " + frame.GetMethod().Name + "  LINE:  " + frame.GetFileLineNumber();
                Logg.logger.Fatal(ex.Message + altMessage);
                return errorNumber;
            }
            finally
            {
                objCommand.Connection.Close();
            }
        }
        public long update(NpgsqlCommand objCommand)
        {
            var connectionBuilder = new NpgsqlConnectionStringBuilder();
            connectionBuilder.Host = config.AppSettings.Get("DB_Host");
            connectionBuilder.Port = int.Parse(config.AppSettings.Get("DB_Port"));
            connectionBuilder.Database = config.AppSettings.Get("DB_Database");
            connectionBuilder.Username = config.AppSettings.Get("DB_Username");
            connectionBuilder.Password = config.AppSettings.Get("DB_Password");
            connectionBuilder.Timeout = 20;
            connectionBuilder.CommandTimeout = 20;
            var con = new NpgsqlConnection(connectionBuilder.ConnectionString);
            objCommand.CommandType = CommandType.StoredProcedure;
            try
            {
                objCommand.Connection = con;
                objCommand.Connection.Open();
                Logg.logger.Debug(objCommand.CommandText);
                var result = objCommand.ExecuteScalar();
                long val = 0;
                if (long.TryParse(result.ToString(), out val))
                {
                    return val;
                }
                return -1;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return -1;
            }
            finally
            {
                objCommand.Connection.Close();
            }
        }
        public DataSet select(NpgsqlCommand objCommand)
        {
            var connectionBuilder = new NpgsqlConnectionStringBuilder();
            connectionBuilder.Host = config.AppSettings.Get("DB_Host");
            connectionBuilder.Port = int.Parse(config.AppSettings.Get("DB_Port"));
            connectionBuilder.Database = config.AppSettings.Get("DB_Database");
            connectionBuilder.Username = config.AppSettings.Get("DB_Username");
            connectionBuilder.Password = config.AppSettings.Get("DB_Password");
            connectionBuilder.Timeout = 20;
            connectionBuilder.CommandTimeout = 20;
            var con = new NpgsqlConnection(connectionBuilder.ConnectionString);
            objCommand.CommandType = CommandType.StoredProcedure;
            var ds = new DataSet();
            try
            {
                objCommand.Connection = con;
                objCommand.Connection.Open();
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(objCommand);
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return null;
            }
            finally
            {
                objCommand.Connection.Close();
            }
        }
        public void TraceMessage(string message, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "", [CallerLineNumber] int sourceLineNumber = 0)
        {
            Logg.logger.Fatal(message + "  |||  " + memberName + "  |||  " + sourceFilePath + "  |||  " + sourceLineNumber);
        }
    }


    public class element
    {
    }
}
