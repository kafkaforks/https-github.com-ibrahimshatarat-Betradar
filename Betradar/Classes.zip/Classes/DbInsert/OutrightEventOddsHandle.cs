﻿using System;
using System.Collections.Generic;
using System.Linq;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.Lcoo;

namespace Betradar.Classes.DbInsert
{
    public class OutrightEventOddsHandle : Core
    {
        public OutrightEventOddsHandle(OutrightEventOdds args)
        {
            OutrightEventOdds_Queue_WatchQueueMatches(args);
        }
        public void OutrightEventOdds_Queue_WatchQueueMatches(OutrightEventOdds queueElement)
        {
            int maxRetries = 0;
            var common = new Common();
            var queue = new Queue<Globals.Rollback>();
            int.TryParse(config.AppSettings.Get("MaxQueueRetries"), out maxRetries);
            try
            {
                var entity = queueElement.OutrightEntity;

                var objCommand = new NpgsqlCommand(Globals.DB_Functions.InsertOutright.ToDescription());

                //objCommand.Parameters.AddWithValue("fk_feed_type_id", NpgsqlDbType.Bigint, Globals.FeedTypes.OutrightEventOdds);
                if (entity.AamsCalendarId != null)
                {
                    objCommand.Parameters.AddWithValue("aams_calendar_id", NpgsqlDbType.Integer, entity.AamsCalendarId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("aams_calendar_id", NpgsqlDbType.Integer, DBNull.Value);
                }

                if (!string.IsNullOrEmpty(entity.AAmsOutrightIDs))
                {
                    objCommand.Parameters.AddWithValue("aams_outright_id", NpgsqlDbType.Text, entity.AAmsOutrightIDs);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("aams_outright_id", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Category != null)
                {
                    var ret = common.insertCategory(entity.Category);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_category_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_category_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Category, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_category_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.FeedType != null)
                {
                    objCommand.Parameters.AddWithValue("feed_type", NpgsqlDbType.Text, entity.FeedType);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("feed_type", NpgsqlDbType.Text, DBNull.Value);
                }


                if (entity.Fixture != null)
                {
                    var ret = common.insertFixture(entity.Fixture);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Fixture, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Id != null)
                {
                    objCommand.Parameters.AddWithValue("outright_id", NpgsqlDbType.Bigint, entity.Id);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("outright_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.MessageTime != null)
                {
                    objCommand.Parameters.AddWithValue("message_time", NpgsqlDbType.Timestamp, entity.MessageTime);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("message_time", NpgsqlDbType.Timestamp, DBNull.Value);
                }

                if (entity.Odds != null)
                {
                    var ret = common.insertBets(entity.Odds);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_bet_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_bet_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.BetOdds, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_bet_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Result != null)
                {
                    var ret = common.insertOutrightResults(entity.Result);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_outright_result_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_outright_result_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.OutrightResults, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_outright_result_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Sport != null)
                {
                    var ret = common.insertSport(entity.Sport);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Sport, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.StageId != null)
                {
                    objCommand.Parameters.AddWithValue("stage_id", NpgsqlDbType.Bigint, entity.StageId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("stage_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                var ObjId = common.insert(objCommand);

                if (ObjId == -1)
                {
                    queue.Enqueue(SetRollback(ObjId, Globals.Tables.Outright, Globals.TransactionTypes.Insert));
                    throw new Exception("Error in Insert Outright Event Odds");
                }
#if DEBUG
                OutCount += 1;
                Logg.logger.Error("InCount Count = " + InCount + "  ||||| OutCount = " + OutCount);
#endif
            }
            catch (Exception ex)
            {
                common.RollBack(queue.ToList());
                Logg.logger.Fatal(ex.Message);
            }
        }
    }
}
