﻿using System;
using System.Collections.Generic;
using System.Linq;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;

namespace Betradar.Classes.DbInsert
{
    public class ScoreCardSummaryHandle : Core
    {
        public ScoreCardSummaryHandle(ScoreCardSummaryEventArgs args)
        {
            ScoreCardSummary_Queue_WatchQueueMatches(args);
        }
        /// <summary>
        /// This function inserts the comming feed and deques it form the queue
        /// </summary>
        public void ScoreCardSummary_Queue_WatchQueueMatches(ScoreCardSummaryEventArgs queueElement)
        {
            var common = new Common();
            var queue = new Queue<Globals.Rollback>();
            try
            {
                //Additional Data 
                var objCommand = new NpgsqlCommand(Globals.DB_Functions.InsertLive.ToDescription());
                objCommand.Parameters.AddWithValue("fk_feed_type_id", NpgsqlDbType.Bigint, Globals.FeedTypes.ScoreCardSummary);
                if (queueElement.ScoreCardSummary.AdditionalData != null)
                {
                    var ret = common.insertAdditionalData(queueElement.ScoreCardSummary.AdditionalData);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Dictionaries, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_additional_data_id", NpgsqlDbType.Bigint,
                        DBNull.Value);
                }

                //Cards By Time
                if (queueElement.ScoreCardSummary.CardsByTime != null)
                {
                    var ret = common.insertCards(queueElement);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Cards, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_cards_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                objCommand.Parameters.AddWithValue("end_time", NpgsqlDbType.Timestamp, DBNull.Value);

                // Event Header
                if (queueElement.ScoreCardSummary.EventHeader != null)
                {
                    var ret = common.insertEventHeader(queueElement.ScoreCardSummary.EventHeader);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_event_header_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_event_header_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(common.SetRollback(ret.id, Globals.Tables.Event_Header,
                            Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_event_header_id", NpgsqlDbType.Bigint, DBNull.Value);
                }

                objCommand.Parameters.AddWithValue("event_id", NpgsqlDbType.Bigint, DBNull.Value);

                if (queueElement.ScoreCardSummary.IsOutOfBand != null)
                    objCommand.Parameters.AddWithValue("isoutof_band", NpgsqlDbType.Boolean,
                        queueElement.ScoreCardSummary.IsOutOfBand);
                else
                {
                    objCommand.Parameters.AddWithValue("isoutof_band", NpgsqlDbType.Boolean, DBNull.Value);
                }
                if (queueElement.ScoreCardSummary.Messages != null)
                {
                    var ret = common.insertMessages(queueElement.ScoreCardSummary.Messages);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(common.SetRollback(ret.id, Globals.Tables.Messages, Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("fk_messages_id", NpgsqlDbType.Bigint,DBNull.Value);
                }
                if (queueElement.ScoreCardSummary.Msgnr != null)
                    objCommand.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint,
                        queueElement.ScoreCardSummary.Msgnr);
                else
                    objCommand.Parameters.AddWithValue("msgnr", NpgsqlDbType.Bigint,
                        DBNull.Value);
                
                objCommand.Parameters.AddWithValue("fx_odds_id", NpgsqlDbType.Bigint, DBNull.Value);
                objCommand.Parameters.AddWithValue("priority", NpgsqlDbType.Text, DBNull.Value);
                if (queueElement.ScoreCardSummary.ReplyNr != null)
                    objCommand.Parameters.AddWithValue("reply_nr", NpgsqlDbType.Bigint,
                        queueElement.ScoreCardSummary.ReplyNr);
                else
                    objCommand.Parameters.AddWithValue("reply_nr", NpgsqlDbType.Bigint,
                        DBNull.Value);

                if (queueElement.ScoreCardSummary.ReplyType != null)
                    objCommand.Parameters.AddWithValue("odds_reply_type", NpgsqlDbType.Text,queueElement.ScoreCardSummary.ReplyType);
                else
                    objCommand.Parameters.AddWithValue("odds_reply_type", NpgsqlDbType.Text,DBNull.Value);

                if (queueElement.ScoreCardSummary.ServerType != null)
                {
                    objCommand.Parameters.AddWithValue("server_type", NpgsqlDbType.Integer,queueElement.ScoreCardSummary.ServerType);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("server_type", NpgsqlDbType.Integer, DBNull.Value);
                }

                if (queueElement.ScoreCardSummary.ServerVersion != null)
                    objCommand.Parameters.AddWithValue("server_version", NpgsqlDbType.Text,
                        queueElement.ScoreCardSummary.ServerVersion);
                else
                    objCommand.Parameters.AddWithValue("server_version", NpgsqlDbType.Text,
                        DBNull.Value);

                objCommand.Parameters.AddWithValue("start_time", NpgsqlDbType.Timestamp, DBNull.Value);

                if (queueElement.ScoreCardSummary.Status != null)
                    objCommand.Parameters.AddWithValue("odds_status", NpgsqlDbType.Text,
                        queueElement.ScoreCardSummary.Status);
                else
                    objCommand.Parameters.AddWithValue("odds_status", NpgsqlDbType.Text,
                        DBNull.Value);

                if (queueElement.ScoreCardSummary.Time != null)
                    objCommand.Parameters.AddWithValue("time", NpgsqlDbType.Bigint,
                        queueElement.ScoreCardSummary.Time);
                else
                    objCommand.Parameters.AddWithValue("time", NpgsqlDbType.Bigint,
                        DBNull.Value);

                if (queueElement.ScoreCardSummary.Timestamp != null)
                    objCommand.Parameters.AddWithValue("timestamp", NpgsqlDbType.Timestamp,
                        queueElement.ScoreCardSummary.Timestamp);
                else
                    objCommand.Parameters.AddWithValue("timestamp", NpgsqlDbType.Timestamp,
                        DBNull.Value);

                if (queueElement.ScoreCardSummary.VirtualGameId != null)
                    objCommand.Parameters.AddWithValue("virtual_game_id", NpgsqlDbType.Bigint,
                        queueElement.ScoreCardSummary.VirtualGameId);
                else
                {
                    objCommand.Parameters.AddWithValue("virtual_game_id", NpgsqlDbType.Bigint,
                        DBNull.Value);
                }
                var ObjId = common.insert(objCommand);
                if (ObjId == -1)
                {
                    queue.Enqueue(SetRollback(ObjId, Globals.Tables.Live_Common_Feed, Globals.TransactionTypes.Insert));
                    throw new Exception("Error in Insert Score Card Summary");
                }
#if DEBUG
                OutCount += 1;
                Logg.logger.Error("InCount Count = " + InCount + "  ||||| OutCount = " + OutCount);
#endif
            }

            catch (Exception ex)
            {
                if (queue.Count > 0)
                {
                    common.RollBack(queue.ToList());
                }
                Logg.logger.Fatal(ex.Message);
            }
        }
    }
}



