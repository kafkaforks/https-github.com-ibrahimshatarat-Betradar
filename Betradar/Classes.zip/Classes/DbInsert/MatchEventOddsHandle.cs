﻿using System;
using System.Collections.Generic;
using System.Linq;
using Npgsql;
using NpgsqlTypes;
using Sportradar.SDK.FeedProviders.Lcoo;

namespace Betradar.Classes.DbInsert
{
    public class MatchEventOddsHandle : Core
    {

        public MatchEventOddsHandle(MatchEventOdds args)
        {
            MatchEventOdds_Queue_WatchQueueMatches(args);
        }

        public void MatchEventOdds_Queue_WatchQueueMatches(MatchEventOdds queueElement)
        {
            var common = new Common();
            var entity = queueElement.MatchEntity;
            var queue = new Queue<Globals.Rollback>();
            try
            {

                var objCommand = new NpgsqlCommand(Globals.DB_Functions.InsertMatch.ToDescription());
                if (entity.MatchId != null)
                {
                    objCommand.Parameters.AddWithValue("match_id", NpgsqlDbType.Bigint, entity.MatchId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.Aamsids))
                {
                    objCommand.Parameters.AddWithValue("aamsids", NpgsqlDbType.Text, entity.Aamsids);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("aamsids", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.AdditionalData != null)
                {
                    var ret = common.insertAdditionalData(entity.AdditionalData);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("additional_data_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Dictionaries, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("additional_data_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.AwayTeamBetradarMatchId != null)
                {
                    objCommand.Parameters.AddWithValue("away_team_match_id", NpgsqlDbType.Bigint, entity.AwayTeamBetradarMatchId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("away_team_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.AwayTeamMonitoringMatchId != null)
                {
                    objCommand.Parameters.AddWithValue("away_team_monitoring_match_id", NpgsqlDbType.Bigint, entity.AwayTeamMonitoringMatchId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("away_team_monitoring_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.BetdaqId != null)
                {
                    objCommand.Parameters.AddWithValue("betdaq_id", NpgsqlDbType.Text, entity.BetdaqId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("betdaq_id", NpgsqlDbType.Text, DBNull.Value);
                }

                if (entity.BetfairId != null)
                {
                    var id = common.insertBetFairId(entity.BetfairId);
                    queue.Enqueue(SetRollback(id, Globals.Tables.Bet_Fair_Id,
                        Globals.TransactionTypes.Insert));
                    objCommand.Parameters.AddWithValue("betfair_id", NpgsqlDbType.Bigint, id);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("betfair_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.BetResults != null)
                {
                    var ret = common.insertBetResults(entity);
                    objCommand.Parameters.AddWithValue("bet_results", NpgsqlDbType.Bigint, ret.id);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Globals.Tables.BetResults, Globals.TransactionTypes.Insert));
                }
                else
                {
                    objCommand.Parameters.AddWithValue("bet_results", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Cards != null)
                {
                    var ret = common.insertCards(entity.Cards);
                    objCommand.Parameters.AddWithValue("cards_id", NpgsqlDbType.Bigint, ret.id);
                    queue.Enqueue(SetRollback(ret.id, Globals.Tables.Cards, Globals.TransactionTypes.Insert));
                    for (int i = 0; i < ret.queue.Count; i++)
                    {
                        queue.Enqueue(ret.queue.Dequeue());
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("cards_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Category != null)
                {
                    var ret = common.insertCategory(entity.Category);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("category_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("category_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Category, Globals.TransactionTypes.Insert));
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("category_id", DBNull.Value);
                }
                if (entity.Corners != null)
                {
                    var ret = common.insertCorners(entity.Corners);
                    objCommand.Parameters.AddWithValue("corners_id", NpgsqlDbType.Bigint, ret.id);
                    queue.Enqueue(SetRollback(ret.id, Globals.Tables.Corners, Globals.TransactionTypes.Insert));
                    for (int i = 0; i < ret.queue.Count; i++)
                    {
                        queue.Enqueue(ret.queue.Dequeue());
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("corners_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Fixture != null)
                {
                    var ret = common.insertFixture(entity.Fixture);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("fixture_id", NpgsqlDbType.Bigint, ret.id);
                        queue = CloneRollbackQueue(queue, ret.queue);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Fixture, Globals.TransactionTypes.Insert));
                    }

                }
                else
                {
                    objCommand.Parameters.AddWithValue("fixture_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Goals != null)
                {
                    var ret = common.insertGoals(entity.Goals);
                    objCommand.Parameters.AddWithValue("goals_id", NpgsqlDbType.Bigint, ret.id);
                    queue = CloneRollbackQueue(queue, ret.queue);
                    queue.Enqueue(SetRollback(ret.id, Globals.Tables.Goals, Globals.TransactionTypes.Insert));
                }
                else
                {
                    objCommand.Parameters.AddWithValue("goals_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.HomeTeamBetradarMatchId != null)
                {
                    objCommand.Parameters.AddWithValue("home_team_match_id", NpgsqlDbType.Bigint, entity.HomeTeamBetradarMatchId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("home_team_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.HomeTeamMonitoringMatchId != null)
                {
                    objCommand.Parameters.AddWithValue("home_team_monitoring_match_id", NpgsqlDbType.Bigint, entity.HomeTeamMonitoringMatchId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("home_team_monitoring_match_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Information != null)
                {
                    var ret = common.insertTexts(entity.Information);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("information_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("information_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Texts, Globals.TransactionTypes.Insert));
                    }

                }
                else
                {
                    objCommand.Parameters.AddWithValue("information_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.MessageTime != null)
                {
                    objCommand.Parameters.AddWithValue("message_time", NpgsqlDbType.Timestamp, entity.MessageTime);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("message_time", NpgsqlDbType.Timestamp, DBNull.Value);
                }
                if (!string.IsNullOrEmpty(entity.MonitoringMatchId))
                {
                    objCommand.Parameters.AddWithValue("monitoring_match_id", NpgsqlDbType.Text, entity.MonitoringMatchId);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("monitoring_match_id", NpgsqlDbType.Text, DBNull.Value);
                }
                if (entity.Odds != null)
                {
                    var ret = common.insertBets(entity.Odds, entity.MatchId);
                    queue.Enqueue(SetRollback(ret.id, Globals.Tables.Texts, Globals.TransactionTypes.Insert));
                    queue = CloneRollbackQueue(queue, ret.queue);
                    objCommand.Parameters.AddWithValue("bet_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("bet_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Pitcher != null)
                {
                    var id = common.insertHomeAway(entity.Pitcher);
                    queue.Enqueue(SetRollback(id, Globals.Tables.HomeAway, Globals.TransactionTypes.Insert));
                    objCommand.Parameters.AddWithValue("pitcher_id", NpgsqlDbType.Bigint, id);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("pitcher_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Probabilities != null)
                {
                    var ret = common.insertProbabilities(entity.Probabilities);
                    queue.Enqueue(SetRollback(ret.id, Globals.Tables.Probabilities, Globals.TransactionTypes.Insert));
                    for (var i = 0; i < ret.queue.Count; i++)
                    {
                        queue.Enqueue(ret.queue.Dequeue());
                    }
                    objCommand.Parameters.AddWithValue("probability_id", NpgsqlDbType.Bigint, ret.id);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("probability_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Result != null)
                {
                    var ret = common.insertResult(entity.Result);
                    if (ret != null)
                    {
                        for (var i = 0; i < ret.queue.Count; i++)
                        {
                            queue.Enqueue(ret.queue.Dequeue());
                        }
                        objCommand.Parameters.AddWithValue("result_id", NpgsqlDbType.Bigint, ret.id);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("result_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("result_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.RotationNumber != null)
                {
                    var id = common.insertHomeAway(entity.RotationNumber);
                    queue.Enqueue(SetRollback(id, Globals.Tables.HomeAway, Globals.TransactionTypes.Insert));
                    objCommand.Parameters.AddWithValue("rotation_number", NpgsqlDbType.Bigint, id);
                }
                else
                {
                    objCommand.Parameters.AddWithValue("rotation_number", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Sport != null)
                {
                    var ret = common.insertSport(entity.Sport);
                    if (ret != null)
                    {
                        for (int i = 0; i < ret.queue.Count; i++)
                        {
                            queue.Enqueue(ret.queue.Dequeue());
                        }
                        objCommand.Parameters.AddWithValue("sport_id", NpgsqlDbType.Bigint, ret.id);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("sport_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.Tournament != null)
                {
                    var ret = common.insertTournament(entity.Tournament);
                    if (ret.id == -1)
                    {
                        objCommand.Parameters.AddWithValue("tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                    }
                    else
                    {
                        objCommand.Parameters.AddWithValue("tournament_id", NpgsqlDbType.Bigint, ret.id);
                        queue.Enqueue(SetRollback(ret.id, Globals.Tables.Tournament, Globals.TransactionTypes.Insert));
                        queue = CloneRollbackQueue(queue, ret.queue);
                    }

                }
                else
                {
                    objCommand.Parameters.AddWithValue("tournament_id", NpgsqlDbType.Bigint, DBNull.Value);
                }
                if (entity.TvChannels != null)
                {
                    var ret = common.insertTvChannels(entity.TvChannels);
                    if (ret != null)
                    {
                        for (int i = 0; i < ret.queue.Count; i++)
                        {
                            queue.Enqueue(ret.queue.Dequeue());
                        }
                        objCommand.Parameters.AddWithValue("tv_channels_id", NpgsqlDbType.Bigint, ret.id);
                    }
                }
                else
                {
                    objCommand.Parameters.AddWithValue("tv_channels_id", NpgsqlDbType.Bigint, DBNull.Value);
                }

                var ObjId = common.insert(objCommand);

                if (ObjId == -1)
                {
                    queue.Enqueue(SetRollback(ObjId, Globals.Tables.Live_Common_Feed, Globals.TransactionTypes.Insert));
                    throw new Exception("Error in Insert Match Event Odds");
                }
#if DEBUG
                OutCount += 1;
                Logg.logger.Error("InCount Count = " + InCount + "  ||||| OutCount = " + OutCount);
#endif
            }
            catch (Exception ex)
            {
                if (queue.Count > 0)
                {
                    common.RollBack(queue.ToList());
                }
                Logg.logger.Fatal(ex.Message);
            }
        }
    }
}
