﻿using System;

namespace Betradar.Classes.DbInsert
{
    [Serializable]
   public class feed
    {
        public string RawFeed { get; set; }
    }
}
