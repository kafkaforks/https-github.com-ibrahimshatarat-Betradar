﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
using NLog.Fluent;
using RestSharp.Authenticators;
using Sportradar.SDK.FeedProviders.LiveOdds.Common;

namespace Betradar.Classes
{
    public abstract class LiveOddsCommonModule : LiveOddsCommonBaseModule
    {
        private readonly ILiveOddsCommon m_live_odds;

        protected LiveOddsCommonModule(ILiveOddsCommon live_odds, string feed_name, TimeSpan meta_interval)
            : base(live_odds, feed_name, meta_interval)
        {
            m_live_odds = live_odds;
            m_live_odds.OnAlive += AliveHandler;
        }

        protected virtual void AliveHandler(object sender, AliveEventArgs e)
        {
            Logg.logger.Info("{0}: Received alive with {1} events", m_feed_name, e.Alive.EventHeaders.Count);
        }
    }
}
