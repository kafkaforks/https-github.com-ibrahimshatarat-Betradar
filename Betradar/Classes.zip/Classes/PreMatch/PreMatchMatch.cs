﻿#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

#endregion


namespace Betradar.Classes.DB
{
    public interface IPreMatchMatch
    {
        long MatchId { get; set; }
        DateTime MatchDate { get; set; }
        int TournamentId { get; set; }
        long? HomeId { get; set; }
        string HomeName { get; set; }
        long? AwayId { get; set; }
        string AwayName { get; set; }
        bool NeutralGround { get; set; }
        bool Live { get; set; }
        bool HasStatistics { get; set; }
        bool HasTvInfo { get; set; }
        IList<Bets> Bets { get; set; }
    }

    [Serializable]
    [DataContract]
    public class PreMatchMatch : IPreMatchMatch
    {
        #region Constractor

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public PreMatchMatch()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public PreMatchMatch(long pMatchId,DateTime pMatchDate,int pTournamentId,long? pHomeId,string pHomeName,long? pAwayId,string pAwayName,bool pNeutralGround,bool pLive,bool pHasStatistics,bool pHasTvInfo)
        {
            MatchId=pMatchId;
            MatchDate=pMatchDate;
            TournamentId=pTournamentId;
            HomeId=pHomeId;
            HomeName=pHomeName;
            AwayId=pAwayId;
            AwayName=pAwayName;
            NeutralGround=pNeutralGround;
            Live=pLive;
            HasStatistics=pHasStatistics;
            HasTvInfo=pHasTvInfo;
            Bets=new List<Bets>();
        }

        #endregion


        #region  Proporties

        [DataMember(Name="Mid")]
        public long MatchId { get;  set; }
        [DataMember(Name="Md")]
        public DateTime MatchDate { get;  set; }
        [DataMember(Name="Tid")]
        public int TournamentId { get;  set; }

        [DataMember(Name="Hid")]
        public long? HomeId { get;  set; }
        [DataMember(Name="Hn")]
        public string HomeName { get;  set; }
        [DataMember(Name="Aid")]
        public long? AwayId { get;  set; }
        [DataMember(Name="An")]
        public string AwayName { get;  set; }
        [DataMember(Name="Ng")]
        public bool NeutralGround { get;  set; }
        [DataMember(Name="L")]
        public bool Live { get;  set; }
        [DataMember(Name="Hs")]
        public bool HasStatistics { get;  set; }
        [DataMember(Name="Htv")]
        public bool HasTvInfo { get;  set; }
        [DataMember(Name="Bets")]
        public IList<Bets> Bets { get; set; }

        #endregion


        #region Methods


        #region Public Methods

        /// <summary>
        ///     Determines whether the specified object is equal to the current object.
        /// </summary>
        /// <returns>
        ///     true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>
        /// <param name="pObj">The object to compare with the current object. </param>
        public override bool Equals(object pObj)
        {
            if(ReferenceEquals(null,pObj))
            {
                return false;
            }
            if(ReferenceEquals(this,pObj))
            {
                return true;
            }
            if(pObj.GetType()!=GetType())
            {
                return false;
            }
            return Equals((PreMatchMatch)pObj);
        }

        /// <summary>
        ///     Serves as the default hash function.
        /// </summary>
        /// <returns>
        ///     A hash code for the current object.
        /// </returns>
        public override int GetHashCode()
        {
            unchecked
            {
                return (MatchId.GetHashCode()*397)^MatchDate.GetHashCode();
            }
        }

        public static bool operator ==(PreMatchMatch pLeft,PreMatchMatch pRight)
        {
            return Equals(pLeft,pRight);
        }

        public static bool operator !=(PreMatchMatch pLeft,PreMatchMatch pRight)
        {
            return !Equals(pLeft,pRight);
        }

        /// <summary>
        ///     Returns a string that represents the current object.
        /// </summary>
        /// <returns>
        ///     A string that represents the current object.
        /// </returns>
        public override string ToString()
        {
            return $"MatchId: {MatchId}, MatchDate: {MatchDate}, TournamentId: {TournamentId}, HomeId: {HomeId}, HomeName: {HomeName}, AwayId: {AwayId}, AwayName: {AwayName}, NeutralGround: {NeutralGround}, Live: {Live}, HasStatistics: {HasStatistics}, HasTvInfo: {HasTvInfo}";
        }

        #endregion


        #region Protected Methods

        protected bool Equals(PreMatchMatch pOther)
        {
            return MatchId==pOther.MatchId&&MatchDate.Equals(pOther.MatchDate);
        }

        #endregion


        #endregion
    }
}