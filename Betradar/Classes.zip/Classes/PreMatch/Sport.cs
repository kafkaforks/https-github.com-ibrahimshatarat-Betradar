﻿#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;


#endregion


namespace Betradar.Classes.DB
{
    public interface ISport
    {
        /// <summary>
        ///     Sport Id
        /// </summary>
        int SportId { get; set; }

        /// <summary>
        ///     Sport Name
        /// </summary>
        string SportName { get; set; }

        /// <summary>
        ///     How many Match There are in this sport
        /// </summary>
        int? MatchCount { get; set; }

        /// <summary>
        ///     List of This Sport's Categories
        /// </summary>
        IList<Category> Categories { get; set; }
    }

    [DataContract]
    [Serializable]
    public class Sport : ISport
    {
        #region Constractor

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Sport()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        /// <param name="pSportId">Sport Id (Internal Sport Id)</param>
        /// <param name="pSportName">Sport Name</param>
        /// <param name="pMatchCount">How many match there are in this Sport</param>
        public Sport(int pSportId,string pSportName,int? pMatchCount)
        {
            SportId=pSportId;
            SportName=pSportName;
            MatchCount=pMatchCount;
            Categories=new List<Category>();
        }

        #endregion


        #region  Proporties

        /// <summary>
        ///     Sport Id
        /// </summary>
        [DataMember(Name="Sid")]
        public int SportId { get; set; }
        /// <summary>
        ///     Sport Name
        /// </summary>
        [DataMember(Name="Sn")]
        public string SportName { get; set; }
        /// <summary>
        ///     How many Match There are in this sport
        /// </summary>
        [DataMember(Name="Mc")]
        public int? MatchCount { get; set; }
        /// <summary>
        ///     List of This Sport's Categories
        /// </summary>
        [DataMember(Name="Cats")]
        public IList<Category> Categories { get; set; }

        #endregion


        #region Methods


        #region Public Methods

        /// <summary>
        ///     Determines whether the specified object is equal to the current object.
        /// </summary>
        /// <returns>
        ///     true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>
        /// <param name="pObj">The object to compare with the current object. </param>
        public override bool Equals(object pObj)
        {
            if(ReferenceEquals(null,pObj))
            {
                return false;
            }
            if(ReferenceEquals(this,pObj))
            {
                return true;
            }
            if(pObj.GetType()!=GetType())
            {
                return false;
            }
            return Equals((Sport)pObj);
        }

        /// <summary>
        ///     Serves as the default hash function.
        /// </summary>
        /// <returns>
        ///     A hash code for the current object.
        /// </returns>
        public override int GetHashCode()
        {
            return SportId;
        }

        public static bool operator ==(Sport pLeft,Sport pRight)
        {
            return Equals(pLeft,pRight);
        }

        public static bool operator !=(Sport pLeft,Sport pRight)
        {
            return !Equals(pLeft,pRight);
        }

        /// <summary>
        ///     Returns a string that represents the current object.
        /// </summary>
        /// <returns>
        ///     A string that represents the current object.
        /// </returns>
        public override string ToString()
        {
            return $"SportId: {SportId}, SportName: {SportName}, MatchCount: {MatchCount}, Categories: {Categories}";
        }

        #endregion


        #region Protected Methods

        protected bool Equals(Sport pOther)
        {
            return SportId==pOther.SportId;
        }

        #endregion


        #endregion
    }
}