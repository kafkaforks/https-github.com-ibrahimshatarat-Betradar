﻿
#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;


#endregion


namespace Betradar.Classes.DB
{
    public interface ITournament
    {
        /// <summary>
        ///     Category Id of this Tournament
        /// </summary>
        int CategoryId { get; set; }

        /// <summary>
        ///     Tournament Id of this Objact (Internal Tournament Id)
        /// </summary>
        int TournamentId { get; set; }

        /// <summary>
        ///     Tournament Name
        /// </summary>
        string TournamentName { get; set; }

        /// <summary>
        ///     How many match there are in this tournament
        /// </summary>
        int? MatchCount { get; set; }

        /// <summary>
        ///     List of Matches
        /// </summary>
        List<PreMatchMatch> Matches { get; set; }
    }

    [Serializable]
    [DataContract]

    public class Tournament : ITournament
    {
        #region Constractor

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Tournament()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        /// <param name="pCategoryId">Category Id of this Tournament</param>
        /// <param name="pTournamentId">Tournament Id of this Objact (Internal Tournament Id)</param>
        /// <param name="pTournamentName">Tournament Name</param>
        /// <param name="pMatchCount">How many match there are in this tournament</param>
        public Tournament(int pCategoryId,int pTournamentId,string pTournamentName,int? pMatchCount)
        {
            CategoryId=pCategoryId;
            TournamentId=pTournamentId;
            TournamentName=pTournamentName;
            MatchCount=pMatchCount;
        }


        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        /// <param name="pCategoryId">Category Id of this Tournament</param>
        /// <param name="pTournamentId">Tournament Id of this Objact (Internal Tournament Id)</param>
        /// <param name="pTournamentName">Tournament Name</param>
        /// <param name="pMatchCount">How many match there are in this tournament</param>
        /// <param name="pHasMatch">Has Match</param>
        public Tournament(int pCategoryId,int pTournamentId,string pTournamentName,int? pMatchCount,bool pHasMatch)
        {
            CategoryId=pCategoryId;
            TournamentId=pTournamentId;
            TournamentName=pTournamentName;
            MatchCount=pMatchCount;
            if(pHasMatch)
            {
                Matches=new List<PreMatchMatch>();
            }
        }

        #endregion


        #region  Proporties

        /// <summary>
        ///     Category Id of this Tournament
        /// </summary>
        [DataMember(Name="Cid")]
        public int CategoryId { get;  set; }
        /// <summary>
        ///     Tournament Id of this Objact (Internal Tournament Id)
        /// </summary>
        [DataMember(Name="Tid")]
        public int TournamentId { get;  set; }
        /// <summary>
        ///     Tournament Name
        /// </summary>
        [DataMember(Name="Tn")]
        public string TournamentName { get;  set; }
        /// <summary>
        ///     How many match there are in this tournament
        /// </summary>
        [DataMember(Name="Mc")]
        public int? MatchCount { get;  set; }

        /// <summary>
        ///     List of Matches
        /// </summary>
        [DataMember(Name="M")]
        public List<PreMatchMatch> Matches { get; set; }

        #endregion


        #region Methods


        #region Public Methods

        /// <summary>
        ///     Determines whether the specified object is equal to the current object.
        /// </summary>
        /// <returns>
        ///     true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>
        /// <param name="pObj">The object to compare with the current object. </param>
        public override bool Equals(object pObj)
        {
            if(ReferenceEquals(null,pObj))
            {
                return false;
            }
            if(ReferenceEquals(this,pObj))
            {
                return true;
            }
            if(pObj.GetType()!=typeof(Tournament))
            {
                return false;
            }
            return Equals((Tournament)pObj);
        }

        /// <summary>
        ///     Serves as the default hash function.
        /// </summary>
        /// <returns>
        ///     A hash code for the current object.
        /// </returns>
        public override int GetHashCode()
        {
            return TournamentId;
        }

        public static bool operator ==(Tournament pLeft,Tournament pRight)
        {
            return Equals(pLeft,pRight);
        }

        public static bool operator !=(Tournament pLeft,Tournament pRight)
        {
            return !Equals(pLeft,pRight);
        }


        /// <summary>
        ///     Returns a string that represents the current object.
        /// </summary>
        /// <returns>
        ///     A string that represents the current object.
        /// </returns>
        public override string ToString()
        {
            return $"CategoryId: {CategoryId}, TournamentId: {TournamentId}, TournamentName: {TournamentName}, MatchCount: {MatchCount}";
        }

        #endregion


        #region Protected Methods

        protected bool Equals(Tournament pOther)
        {
            return TournamentId==pOther.TournamentId;
        }

        #endregion


        #endregion
    }
}