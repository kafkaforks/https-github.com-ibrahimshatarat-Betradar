﻿#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

#endregion


namespace Betradar.Classes.DB
{
    public interface ICategory
    {
        /// <summary>
        ///     Sport's Id of this Category
        /// </summary>
        int SportId { get; set; }

        /// <summary>
        ///     Category Id of this object (Internal Category Id)
        /// </summary>
        int CategoryId { get; set; }

        /// <summary>
        ///     Name of This category
        /// </summary>
        string CategoryName { get; set; }

        /// <summary>
        ///     Iso country code if provided. (for menu flag)
        /// </summary>
        string Iso { get; set; }

        /// <summary>
        ///     How many match there are in this Category
        /// </summary>
        int? MatchCount { get; set; }

        /// <summary>
        ///     List of tournaments for this Category
        /// </summary>
        IList<Tournament> Tournaments { get; set; }
    }

    [Serializable]
    [DataContract]
    public class Category : ICategory
    {
        #region Constractor

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Category()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        /// <param name="pSportId">Sport's Id of this Category</param>
        /// <param name="pCategoryId">Category Id of this object (Internal Category Id)</param>
        /// <param name="pCategoryName">Name of This category</param>
        /// <param name="pIso">Iso country code if provided. (for menu flag)</param>
        public Category(int pSportId,int pCategoryId,string pCategoryName,string pIso)
        {
            SportId=pSportId;
            CategoryId=pCategoryId;
            CategoryName=pCategoryName;
            Iso=pIso;
            MatchCount=0;
            Tournaments=new List<Tournament>();
        }


        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        /// <param name="pSportId">Sport's Id of this Category</param>
        /// <param name="pCategoryId">Category Id of this object (Internal Category Id)</param>
        /// <param name="pCategoryName">Name of This category</param>
        /// <param name="pIso">Iso country code if provided. (for menu flag)</param>
        /// <param name="pMatchCount">How many match there are in this Category</param>
        public Category(int pSportId,int pCategoryId,string pCategoryName,string pIso,int? pMatchCount)
        {
            SportId=pSportId;
            CategoryId=pCategoryId;
            CategoryName=pCategoryName;
            Iso=pIso;
            MatchCount=pMatchCount;
            Tournaments=new List<Tournament>();
        }

        #endregion


        #region  Proporties

        /// <summary>
        ///     Sport's Id of this Category
        /// </summary>
        [DataMember(Name="Sid")]
        public int SportId { get;  set; }
        /// <summary>
        ///     Category Id of this object (Internal Category Id)
        /// </summary>
        [DataMember(Name="Cid")]
        public int CategoryId { get;  set; }
        /// <summary>
        ///     Name of This category
        /// </summary>
        [DataMember(Name="Cn")]
        public string CategoryName { get;  set; }
        /// <summary>
        ///     Iso country code if provided. (for menu flag)
        /// </summary>
        [DataMember(Name="I")]
        public string Iso { get;  set; }
        /// <summary>
        ///     How many match there are in this Category
        /// </summary>
        [DataMember(Name="Mc")]
        public int? MatchCount { get; set; }
        /// <summary>
        ///     List of tournaments for this Category
        /// </summary>
        [DataMember(Name="Trn")]
        public IList<Tournament> Tournaments { get; set; }

        #endregion


        #region Methods


        #region Public Methods

        /// <summary>
        ///     Determines whether the specified object is equal to the current object.
        /// </summary>
        /// <returns>
        ///     true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>
        /// <param name="pObj">The object to compare with the current object. </param>
        public override bool Equals(object pObj)
        {
            if(ReferenceEquals(null,pObj))
            {
                return false;
            }
            if(ReferenceEquals(this,pObj))
            {
                return true;
            }
            if(pObj.GetType()!=typeof(Category))
            {
                return false;
            }
            return Equals((Category)pObj);
        }

        /// <summary>
        ///     Serves as the default hash function.
        /// </summary>
        /// <returns>
        ///     A hash code for the current object.
        /// </returns>
        public override int GetHashCode()
        {
            return CategoryId;
        }

        public static bool operator ==(Category pLeft,Category pRight)
        {
            return Equals(pLeft,pRight);
        }

        public static bool operator !=(Category pLeft,Category pRight)
        {
            return !Equals(pLeft,pRight);
        }

        /// <summary>
        ///     Returns a string that represents the current object.
        /// </summary>
        /// <returns>
        ///     A string that represents the current object.
        /// </returns>
        public override string ToString()
        {
            return $"SportId: {SportId}, CategoryId: {CategoryId}, CategoryName: {CategoryName}, Iso: {Iso}, MatchCount: {MatchCount}, Tournaments: {Tournaments}";
        }

        #endregion


        #region Protected Methods

        protected bool Equals(Category pOther)
        {
            return CategoryId==pOther.CategoryId;
        }

        #endregion


        #endregion
    }
}