﻿#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

#endregion


namespace Betradar.Classes.DB
{
    public interface IBets
    {
        long MatchId { get; set; }
        long BetId { get; set; }
        string OddsType { get; set; }
        string SpecialValue { get; set; }
        bool Active { get; set; }
        IList<Odds> Odds { get; set; }
    }

    [Serializable]
    [DataContract]
    public class Bets : IBets
    {
        #region Constractor

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Bets()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Bets(long pMatchId,long pBetId,string pOddsType,string pSpecialValue,bool pActive)
        {
            MatchId=pMatchId;
            BetId=pBetId;
            OddsType=pOddsType;
            SpecialValue=pSpecialValue;
            Active=pActive;
            Odds=new List<Odds>();
        }

        #endregion


        #region  Proporties

        [DataMember(Name="Mid")]
        public long MatchId { get; set; }
        [DataMember(Name="Bid")]
        public long BetId { get; set; }
        [DataMember(Name="Ot")]
        public string OddsType { get; set; }
        [DataMember(Name="Otn")]
        public string SpecialValue { get; set; }
        [DataMember(Name="Act")]
        public bool Active { get; set; }
        [DataMember(Name="O")]
        public IList<Odds> Odds { get; set; }

        #endregion


        #region Methods


        #region Public Methods

        /// <summary>
        ///     Determines whether the specified object is equal to the current object.
        /// </summary>
        /// <returns>
        ///     true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>
        /// <param name="pObj">The object to compare with the current object. </param>
        public override bool Equals(object pObj)
        {
            if(ReferenceEquals(null,pObj))
            {
                return false;
            }
            if(ReferenceEquals(this,pObj))
            {
                return true;
            }
            if(pObj.GetType()!=GetType())
            {
                return false;
            }
            return Equals((Bets)pObj);
        }

        /// <summary>
        ///     Serves as the default hash function.
        /// </summary>
        /// <returns>
        ///     A hash code for the current object.
        /// </returns>
        public override int GetHashCode()
        {
            return BetId.GetHashCode();
        }

        public static bool operator ==(Bets pLeft,Bets pRight)
        {
            return Equals(pLeft,pRight);
        }

        public static bool operator !=(Bets pLeft,Bets pRight)
        {
            return !Equals(pLeft,pRight);
        }

        /// <summary>
        ///     Returns a string that represents the current object.
        /// </summary>
        /// <returns>
        ///     A string that represents the current object.
        /// </returns>
        //public override string ToString()
        //{
        //    return $"MatchId :{MatchId}, BetId: {BetId}, OddsType: {OddsType}, SpecialValue: {SpecialValue}, Active: {Active}";
        //}

        #endregion


        #region Protected Methods

        protected bool Equals(Bets pOther)
        {
            return BetId==pOther.BetId;
        }

        #endregion


        #endregion
    }
}