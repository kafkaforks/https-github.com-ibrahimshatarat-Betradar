﻿#region Usings

using System;
using System.Runtime.Serialization;

#endregion


namespace Betradar.Classes.DB
{
    public interface IOdds
    {
        long BetId { get; set; }
        long OddsId { get; set; }
        long? OutcomeId { get; set; }
        string Outcome { get; set; }
        string OutcomeFormat { get; set; }
        bool OddsActive { get; set; }
        double OddsValue { get; set; }
        double? Probabilitiy { get; set; }
    }

    [Serializable]
    [DataContract]
    public class Odds : IOdds
    {
        #region Constractor

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Odds()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="T:System.Object" /> class.
        /// </summary>
        public Odds(long pBetId,long pOddsId,long? pOutcomeId,string pOutcome,string pOutcomeFormat,bool pOddsActive,double pOddsValue,double? pProbabilitiy,string pHomeName,string pAwayName)
        {
            BetId=pBetId;
            OddsId=pOddsId;
            OutcomeId=pOutcomeId;
            Outcome=pOutcome;
            OutcomeFormat=pOutcomeFormat;
            OddsActive=pOddsActive;
            if(!string.IsNullOrEmpty(pOutcomeFormat))
            {
                OutcomeFormat=string.Format(pOutcomeFormat,pHomeName,pAwayName);
            } else
            {
                OutcomeFormat=pOutcome;
            }
            OddsValue=pOddsValue;
            Probabilitiy=pProbabilitiy;
        }

        #endregion


        #region  Proporties

        [DataMember(Name="Bid")]
        public long BetId { get; set; }
        [DataMember(Name="Oid")]
        public long OddsId { get; set; }
        [DataMember(Name="Oc")]
        public long? OutcomeId { get; set; }
        [DataMember(Name="Ocn")]
        public string Outcome { get; set; }
        [DataMember(Name="Ocf")]
        public string OutcomeFormat { get; set; }
        [DataMember(Name="Act")]
        public bool OddsActive { get; set; }
        [DataMember(Name="Ov")]
        public double OddsValue { get; set; }
        [DataMember(Name="Pr")]
        public double? Probabilitiy { get; set; }

        #endregion


        #region Methods


        #region Public Methods

        /// <summary>
        ///     Determines whether the specified object is equal to the current object.
        /// </summary>
        /// <returns>
        ///     true if the specified object  is equal to the current object; otherwise, false.
        /// </returns>
        /// <param name="pObj">The object to compare with the current object. </param>
        public override bool Equals(object pObj)
        {
            if(ReferenceEquals(null,pObj))
            {
                return false;
            }
            if(ReferenceEquals(this,pObj))
            {
                return true;
            }
            if(pObj.GetType()!=GetType())
            {
                return false;
            }
            return Equals((Odds)pObj);
        }

        /// <summary>
        ///     Serves as the default hash function.
        /// </summary>
        /// <returns>
        ///     A hash code for the current object.
        /// </returns>
        public override int GetHashCode()
        {
            unchecked
            {
                return (BetId.GetHashCode()*397)^OddsId.GetHashCode();
            }
        }

        public static bool operator ==(Odds pLeft,Odds pRight)
        {
            return Equals(pLeft,pRight);
        }

        public static bool operator !=(Odds pLeft,Odds pRight)
        {
            return !Equals(pLeft,pRight);
        }

        /// <summary>
        ///     Returns a string that represents the current object.
        /// </summary>
        /// <returns>
        ///     A string that represents the current object.
        /// </returns>
        public override string ToString()
        {
            return $"BetId: {BetId}, OddsId: {OddsId}, OutcomeId: {OutcomeId}, Outcome: {Outcome}, OutcomeFormat: {OutcomeFormat}, OddsActive: {OddsActive}, OddsValue: {OddsValue}, Probabilitiy: {Probabilitiy}";
        }

        #endregion


        #region Protected Methods

        protected bool Equals(Odds pOther)
        {
            return BetId==pOther.BetId&&OddsId==pOther.OddsId;
        }

        #endregion


        #endregion
    }
}