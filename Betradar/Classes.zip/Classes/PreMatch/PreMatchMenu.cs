﻿#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;


#endregion


namespace Betradar.Classes.DB
{
    public interface IPreMatchMenu
    {
        /// <summary>
        ///     Object Generation Time
        /// </summary>
        DateTime GenerationDate { get; set; }

        /// <summary>
        ///     List of Menu's Sports
        /// </summary>
        List<Sport> Sports { get; set; }
    }

    [Serializable]
    [DataContract]
    public class PreMatchMenu : IPreMatchMenu
    {
        #region Constractor

        public PreMatchMenu()
        {
            GenerationDate=DateTime.UtcNow;
            Sports=new List<Sport>();
        }

        #endregion


        #region  Proporties

        /// <summary>
        ///     Object Generation Time
        /// </summary>
        [DataMember(Name="Gd")]
        public DateTime GenerationDate { get;  set; }
        /// <summary>
        ///     List of Menu's Sports
        /// </summary>
        [DataMember(Name="S")]
        public List<Sport> Sports { get; set; }

        #endregion
    }
}