﻿#region Usings

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

#endregion


namespace Betradar.Classes.DB
{
    public interface IPreMatch
    {
        DateTime GenerationTime { get; set; }
        IList<Sport> Sports { get; set; }
    }

    [Serializable]
    [DataContract]
    public class PreMatch : IPreMatch
    {
        public PreMatch()
        {
            this.GenerationTime = DateTime.UtcNow;
        }

        #region  Proporties

        [DataMember]
        public DateTime GenerationTime { get; set; }
        [DataMember]
        public IList<Sport> Sports { get; set; }

        #endregion
    }
}