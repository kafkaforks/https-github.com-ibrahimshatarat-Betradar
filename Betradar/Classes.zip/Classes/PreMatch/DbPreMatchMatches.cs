﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Betradar.Classes.DB
{
    class DbPreMatchMatches
    {
        #region  Proporties

        public long MatchId { get; set; }
        public DateTime MatchDate { get; set; }
        public int SportId { get; set; }
        public int CategoryId { get; set; }
        public int TournamentId { get; set; }
        public string SportName { get; set; }
        public string CategoryName { get; set; }
        public string Iso { get; set; }
        public string TournamentName { get; set; }
        public long? HomeId { get; set; }
        public string HomeName { get; set; }
        public long? AwayId { get; set; }
        public string AwayName { get; set; }
        public bool NeutralGround { get; set; }
        public bool Live { get; set; }
        public bool HasStatistics { get; set; }
        public bool HasTvInfo { get; set; }
        public long BetId { get; set; }
        public bool BetActive { get; set; }
        public string OddsType { get; set; }
        public string SpecialValue { get; set; }
        public long OddsId { get; set; }
        public long? OutcomeId { get; set; }
        public string Outcome { get; set; }
        public string OutcomeFormat { get; set; }
        public bool OddsActive { get; set; }
        public double OddsValue { get; set; }
        public double? Probabilitiy { get; set; }

        #endregion
    }
}
