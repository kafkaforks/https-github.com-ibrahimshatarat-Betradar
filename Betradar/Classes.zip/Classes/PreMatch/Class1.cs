﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Betradar.Classes
{
    public class Class1
    {
       
        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute]
        [System.Xml.Serialization.XmlRootAttribute]
        public partial class BetradarBetData
        {
            public BetradarBetData()
            {
                XmlRootAttribute xRoot = new XmlRootAttribute();
                xRoot.ElementName = "BetradarBetData";
            }

            private BetradarBetDataTimestamp timestampField;

            private BetradarBetDataSport[] sportsField;

            /// <remarks/>
            public BetradarBetDataTimestamp Timestamp
            {
                get
                {
                    return this.timestampField;
                }
                set
                {
                    this.timestampField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Sport", IsNullable = false)]
            public BetradarBetDataSport[] Sports
            {
                get
                {
                    return this.sportsField;
                }
                set
                {
                    this.sportsField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataTimestamp
        {

            private System.DateTime createdTimeField;

            private string timeZoneField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public System.DateTime CreatedTime
            {
                get
                {
                    return this.createdTimeField;
                }
                set
                {
                    this.createdTimeField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string TimeZone
            {
                get
                {
                    return this.timeZoneField;
                }
                set
                {
                    this.timeZoneField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSport
        {

            private BetradarBetDataSportText[] textsField;

            private BetradarBetDataSportCategory[] categoryField;

            private byte betradarSportIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Text", IsNullable = false)]
            public BetradarBetDataSportText[] Texts
            {
                get
                {
                    return this.textsField;
                }
                set
                {
                    this.textsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Category")]
            public BetradarBetDataSportCategory[] Category
            {
                get
                {
                    return this.categoryField;
                }
                set
                {
                    this.categoryField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public byte BetradarSportID
            {
                get
                {
                    return this.betradarSportIDField;
                }
                set
                {
                    this.betradarSportIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportText
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategory
        {

            private BetradarBetDataSportCategoryText[] textsField;

            private BetradarBetDataSportCategoryTournament[] tournamentField;

            private ushort betradarCategoryIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Text", IsNullable = false)]
            public BetradarBetDataSportCategoryText[] Texts
            {
                get
                {
                    return this.textsField;
                }
                set
                {
                    this.textsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Tournament")]
            public BetradarBetDataSportCategoryTournament[] Tournament
            {
                get
                {
                    return this.tournamentField;
                }
                set
                {
                    this.tournamentField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public ushort BetradarCategoryID
            {
                get
                {
                    return this.betradarCategoryIDField;
                }
                set
                {
                    this.betradarCategoryIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryText
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournament
        {

            private BetradarBetDataSportCategoryTournamentText[] textsField;

            private BetradarBetDataSportCategoryTournamentMatch[] matchField;

            private ushort betradarTournamentIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Text", IsNullable = false)]
            public BetradarBetDataSportCategoryTournamentText[] Texts
            {
                get
                {
                    return this.textsField;
                }
                set
                {
                    this.textsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Match")]
            public BetradarBetDataSportCategoryTournamentMatch[] Match
            {
                get
                {
                    return this.matchField;
                }
                set
                {
                    this.matchField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public ushort BetradarTournamentID
            {
                get
                {
                    return this.betradarTournamentIDField;
                }
                set
                {
                    this.betradarTournamentIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentText
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatch
        {

            private BetradarBetDataSportCategoryTournamentMatchFixture fixtureField;

            private BetradarBetDataSportCategoryTournamentMatchBet[] matchOddsField;

            private uint betradarMatchIDField;

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixture Fixture
            {
                get
                {
                    return this.fixtureField;
                }
                set
                {
                    this.fixtureField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Bet", IsNullable = false)]
            public BetradarBetDataSportCategoryTournamentMatchBet[] MatchOdds
            {
                get
                {
                    return this.matchOddsField;
                }
                set
                {
                    this.matchOddsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint BetradarMatchID
            {
                get
                {
                    return this.betradarMatchIDField;
                }
                set
                {
                    this.betradarMatchIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixture
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitors competitorsField;

            private BetradarBetDataSportCategoryTournamentMatchFixtureDateInfo dateInfoField;

            private BetradarBetDataSportCategoryTournamentMatchFixtureStatusInfo statusInfoField;

            private byte neutralGroundField;

            private BetradarBetDataSportCategoryTournamentMatchFixtureRoundInfo roundInfoField;

            private byte numberOfSetsField;

            private bool numberOfSetsFieldSpecified;

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitors Competitors
            {
                get
                {
                    return this.competitorsField;
                }
                set
                {
                    this.competitorsField = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureDateInfo DateInfo
            {
                get
                {
                    return this.dateInfoField;
                }
                set
                {
                    this.dateInfoField = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureStatusInfo StatusInfo
            {
                get
                {
                    return this.statusInfoField;
                }
                set
                {
                    this.statusInfoField = value;
                }
            }

            /// <remarks/>
            public byte NeutralGround
            {
                get
                {
                    return this.neutralGroundField;
                }
                set
                {
                    this.neutralGroundField = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureRoundInfo RoundInfo
            {
                get
                {
                    return this.roundInfoField;
                }
                set
                {
                    this.roundInfoField = value;
                }
            }

            /// <remarks/>
            public byte NumberOfSets
            {
                get
                {
                    return this.numberOfSetsField;
                }
                set
                {
                    this.numberOfSetsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlIgnoreAttribute()]
            public bool NumberOfSetsSpecified
            {
                get
                {
                    return this.numberOfSetsFieldSpecified;
                }
                set
                {
                    this.numberOfSetsFieldSpecified = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitors
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTexts[] textsField;

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer1 player1Field;

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer2 player2Field;

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer3 player3Field;

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer4 player4Field;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Texts")]
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTexts[] Texts
            {
                get
                {
                    return this.textsField;
                }
                set
                {
                    this.textsField = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer1 Player1
            {
                get
                {
                    return this.player1Field;
                }
                set
                {
                    this.player1Field = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer2 Player2
            {
                get
                {
                    return this.player2Field;
                }
                set
                {
                    this.player2Field = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer3 Player3
            {
                get
                {
                    return this.player3Field;
                }
                set
                {
                    this.player3Field = value;
                }
            }

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer4 Player4
            {
                get
                {
                    return this.player4Field;
                }
                set
                {
                    this.player4Field = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTexts
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTextsText textField;

            /// <remarks/>
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTextsText Text
            {
                get
                {
                    return this.textField;
                }
                set
                {
                    this.textField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTextsText
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTextsTextText[] textField;

            private uint idField;

            private uint sUPERIDField;

            private byte typeField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Text")]
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTextsTextText[] Text
            {
                get
                {
                    return this.textField;
                }
                set
                {
                    this.textField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint ID
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint SUPERID
            {
                get
                {
                    return this.sUPERIDField;
                }
                set
                {
                    this.sUPERIDField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public byte Type
            {
                get
                {
                    return this.typeField;
                }
                set
                {
                    this.typeField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsTextsTextText
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer1
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer1Text[] textField;

            private uint idField;

            private uint sUPERIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Text")]
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer1Text[] Text
            {
                get
                {
                    return this.textField;
                }
                set
                {
                    this.textField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint ID
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint SUPERID
            {
                get
                {
                    return this.sUPERIDField;
                }
                set
                {
                    this.sUPERIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer1Text
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer2
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer2Text[] textField;

            private uint idField;

            private uint sUPERIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Text")]
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer2Text[] Text
            {
                get
                {
                    return this.textField;
                }
                set
                {
                    this.textField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint ID
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint SUPERID
            {
                get
                {
                    return this.sUPERIDField;
                }
                set
                {
                    this.sUPERIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer2Text
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer3
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer3Text[] textField;

            private uint idField;

            private uint sUPERIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Text")]
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer3Text[] Text
            {
                get
                {
                    return this.textField;
                }
                set
                {
                    this.textField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint ID
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint SUPERID
            {
                get
                {
                    return this.sUPERIDField;
                }
                set
                {
                    this.sUPERIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer3Text
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer4
        {

            private BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer4Text[] textField;

            private uint idField;

            private uint sUPERIDField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Text")]
            public BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer4Text[] Text
            {
                get
                {
                    return this.textField;
                }
                set
                {
                    this.textField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint ID
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public uint SUPERID
            {
                get
                {
                    return this.sUPERIDField;
                }
                set
                {
                    this.sUPERIDField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureCompetitorsPlayer4Text
        {

            private string valueField;

            private string languageField;

            /// <remarks/>
            public string Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string Language
            {
                get
                {
                    return this.languageField;
                }
                set
                {
                    this.languageField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureDateInfo
        {

            private System.DateTime matchDateField;

            /// <remarks/>
            public System.DateTime MatchDate
            {
                get
                {
                    return this.matchDateField;
                }
                set
                {
                    this.matchDateField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureStatusInfo
        {

            private byte offField;

            /// <remarks/>
            public byte Off
            {
                get
                {
                    return this.offField;
                }
                set
                {
                    this.offField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchFixtureRoundInfo
        {

            private string cuproundField;

            private byte idField;

            private bool idFieldSpecified;

            private byte roundField;

            private bool roundFieldSpecified;

            /// <remarks/>
            public string Cupround
            {
                get
                {
                    return this.cuproundField;
                }
                set
                {
                    this.cuproundField = value;
                }
            }

            /// <remarks/>
            public byte ID
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlIgnoreAttribute()]
            public bool IDSpecified
            {
                get
                {
                    return this.idFieldSpecified;
                }
                set
                {
                    this.idFieldSpecified = value;
                }
            }

            /// <remarks/>
            public byte Round
            {
                get
                {
                    return this.roundField;
                }
                set
                {
                    this.roundField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlIgnoreAttribute()]
            public bool RoundSpecified
            {
                get
                {
                    return this.roundFieldSpecified;
                }
                set
                {
                    this.roundFieldSpecified = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchBet
        {

            private BetradarBetDataSportCategoryTournamentMatchBetOdds[] oddsField;

            private byte oddsTypeField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElement("Odds")]
            public BetradarBetDataSportCategoryTournamentMatchBetOdds[] Odds
            {
                get
                {
                    return this.oddsField;
                }
                set
                {
                    this.oddsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public byte OddsType
            {
                get
                {
                    return this.oddsTypeField;
                }
                set
                {
                    this.oddsTypeField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class BetradarBetDataSportCategoryTournamentMatchBetOdds
        {

            private string outComeField;

            private string specialBetValueField;

            private decimal valueField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string OutCome
            {
                get
                {
                    return this.outComeField;
                }
                set
                {
                    this.outComeField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string SpecialBetValue
            {
                get
                {
                    return this.specialBetValueField;
                }
                set
                {
                    this.specialBetValueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlTextAttribute()]
            public decimal Value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }
        }


    }
}
