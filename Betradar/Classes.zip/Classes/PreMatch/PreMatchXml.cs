﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Betradar.Classes
{
    [XmlRoot("BetradarBetData")]
    public class PreMatchXml
    {
        [XmlElement] public Timestamp Timestamp;
        [XmlElement] public Sports Sports;
    }
    public  class Timestamp
    {
        [XmlAttribute] public CreatedTime CreatedTime;
        [XmlAttribute] public TimeZone TimeZone;
    }

    public class TimeZone
    {
        public string value;
    }

    public class CreatedTime
    {
        public DateTime value;
    }

    [XmlRoot]
    public class Sports
    {
        [XmlElement] public Sport Sport;
    }

    [XmlRoot]
    public class Sport
    {
        [XmlAttribute] public BetradarSportID BetradarSportID;
        [XmlElement] public Texts Texts;
        [XmlElement] public Category Category;
    }

    public class BetradarSportID
    {
        public int id;
    }

    [XmlRoot]
    public class Category
    {
        [XmlAttribute] public BetradarCategoryID BetradarCategoryID;
        [XmlElement] public Texts Texts;
        [XmlElement] public Tournament Tournament;
    }

    public class BetradarCategoryID
    {
        public int id;
    }

    [XmlRoot]
    public class Tournament
    {
        [XmlAttribute] public BetradarTournamentID BetradarTournamentID;
        [XmlElement] public Texts Texts;
        [XmlElement] public Match Match;
    }

    public class BetradarTournamentID
    {
        public int id;
    }

    [XmlRoot]
    public class Match
    {
        [XmlAttribute] public BetradarMatchID BetradarMatchID;
        [XmlElement] public Fixture Fixture;
        [XmlElement] public MatchOdds MatchOdds;
    }

    public class BetradarMatchID
    {
        public int value;
    }

    [XmlRoot]
    public class Fixture
    {
        [XmlElement] public Competitors Competitors;
    }
    [XmlRoot]
    public class Competitors
    {
        [XmlElement] public Texts Texts;
    }
    [XmlRoot]
    public class Text
    {
        [XmlAttribute] public int ID;
        [XmlAttribute] public int SUPERID;
        [XmlAttribute] public int Type;
        [XmlElement] public Text_language Text_language;
    }

    public class Text_language
    {
        [XmlAttribute] public Language Language;
    }

    public class Language
    {
        public string value;
    }

    [XmlRoot]
    public class Text_Value
    {
        [XmlElement]public string Value;
    }

    [XmlRoot]
    public class Texts
    {
        [XmlElement] public Text Text;

    }

    [XmlRoot]
    public class MatchOdds
    {
        [XmlElement] public Bet[] Bet;
    }

    [XmlRoot]
    public class Bet
    {
        [XmlAttribute] public OddsType OddsType;
        [XmlElement] public Odds[] Odds;
    }
    public class OddsType
    {
        public int value;
    }
    public class Odds
    {
        public int value;
        [XmlAttribute]
        public OddsOutcome Outcome;
    }

    public class OddsOutcome
    {
        public int value;
    }
}
