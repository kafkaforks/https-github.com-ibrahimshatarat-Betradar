﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace Betradar.Classes
{
    class DBAccess:Core
    {
        #region Class Variables
        static NpgsqlConnectionStringBuilder connectionBuilder = new Npgsql.NpgsqlConnectionStringBuilder();
        private NpgsqlCommand objCommand;
        private NpgsqlDataReader objReader;
        private NpgsqlDataAdapter objDataAdapter;
        private DataSet ds;
        #endregion Class Variables


        private void connection_build()
        {
            connectionBuilder.Host = Helpers.config.AppSettings.Get("DB_Host");
            connectionBuilder.Port = int.Parse(Helpers.config.AppSettings.Get("DB_Port"));
            connectionBuilder.Database = Helpers.config.AppSettings.Get("DB_Database");
            connectionBuilder.Username = Helpers.config.AppSettings.Get("DB_Username");
            connectionBuilder.Password = Helpers.config.AppSettings.Get("DB_Password");
            connectionBuilder.Timeout = 20;
            connectionBuilder.CommandTimeout = 20;
        }

        public DBAccess()
        {
            connection_build();
        }

        #region Class Methods

        public NpgsqlDataReader SelectDataByReader(string strStoredProcName, ArrayList arrParameters)
        {
            objCommand = new NpgsqlCommand();
            try
            {
                objCommand = CommandBuilder(strStoredProcName, arrParameters);
                objCommand.Connection.Open();
                objReader = objCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                objCommand = null;
                objReader = null;
                Logg.logger.Fatal(ex.Message, "SelectDataByReader().<br>Stored procedure :  " + strStoredProcName + ".", "DBAccess");
            }
            return objReader;
        }

        public DataSet SelectDataBySet(string strStoredProcName, ArrayList arrParameters, string TableName)
        {
            objDataAdapter = new NpgsqlDataAdapter();
            ds = new DataSet();
            try
            {
                objDataAdapter.SelectCommand = CommandBuilder(strStoredProcName, arrParameters);
                objDataAdapter.Fill(ds, TableName);
            }
            catch (Exception ex)
            {
                ds = null;
                Logg.logger.Fatal(ex.Message, "SelectDataBySet().<br>Stored procedure :  " + strStoredProcName + ".", "DBAccess");
            }
            finally
            {
                this.Destruct();
            }
            return ds;
        }

        public DataTable SelectDataByDataTable(string strStoredProcName, ArrayList arrParameters, string TableName)
        {
            objDataAdapter = new NpgsqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                objDataAdapter.SelectCommand = CommandBuilder(strStoredProcName, arrParameters);
                objDataAdapter.Fill(dt);
            }
            catch (Exception ex)
            {
                dt = null;
                 Logg.logger.Fatal(ex.Message, "SelectDataByTable().<br>Stored procedure :  " + strStoredProcName + ".", "DBAccess");
            }
            finally
            {
                this.Destruct();
            }
            return dt;
        }

        public Int64 InsertData(string strStoredProcName, ArrayList arrParameters)
        {
            connection_build();
            var con = new NpgsqlConnection(connectionBuilder.ConnectionString);
            objCommand = new NpgsqlCommand();
            Int64 LastId = 0;
            try
            {

                objCommand = CommandBuilder(strStoredProcName, arrParameters);
                objCommand.Connection = con;
                objCommand.Connection.Open();
                objCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                 Logg.logger.Fatal(ex.Message, "InsertData().<br>Stored procedure :  " + strStoredProcName + ".", "DBAccess");
            }
            finally
            {
                con.Close();
                this.Destruct();
            }
            return LastId;
        }

        protected void UpdateData(string strStoredProcName, ArrayList arrParameters)
        {
            objCommand = new NpgsqlCommand();
            try
            {
                objCommand = CommandBuilder(strStoredProcName, arrParameters);
                objCommand.Connection.Open();
                objCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                objCommand.Connection.Close();
                 Logg.logger.Fatal(ex.Message, "UpdateData().<br>Stored procedure :  " + strStoredProcName + ".", "DBAccess");
            }
        }

        private NpgsqlCommand CommandBuilder(string strProc, ArrayList arrParams)
        {
            connection_build();
            var con = new NpgsqlConnection(connectionBuilder.ConnectionString);
            objCommand = new NpgsqlCommand();
            objCommand.Connection = con;
            objCommand.CommandText = strProc;
            objCommand.CommandType = CommandType.StoredProcedure;
            if (arrParams != null && arrParams.Count > 0)
            {
                foreach (NpgsqlParameter objParam in arrParams)
                {
                    objCommand.Parameters.Add(new NpgsqlParameter(objParam.ParameterName, objParam.DbType));
                    objCommand.Parameters[objParam.ParameterName].Direction = objParam.Direction;
                    objCommand.Parameters[objParam.ParameterName].Value = objParam.Value;
                }
            }

            return objCommand;
        }

        public void Destruct()
        {
            connection_build();
            var con = new NpgsqlConnection(connectionBuilder.ConnectionString);
            if (con != null)
            {
                con.Close();
                con.Dispose();
                con = null;
            }
            objCommand = null;
            objDataAdapter = null;
            GC.Collect();
        }

        #endregion Class Methods
    }


}
