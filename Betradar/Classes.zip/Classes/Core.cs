﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NLog.Internal;
using Npgsql;

namespace Betradar.Classes
{
    public class Core
    {
        static Socket client = new Socket(SocketType.Stream, ProtocolType.IP);
        public static ConfigurationManager config = new ConfigurationManager();
        public static ManualResetEvent ManualReset = new ManualResetEvent(false);
        public static long InCount;
        public static long OutCount;

        
        protected Core()
        {
            try
            {
                //if (client.Connected == false)
                //    client.Connect("172.16.18.8", 22824);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
            }
        }
        public static void sendToNotipier(string jsonObject)
        {
            try
            {
                //if (client.Connected == false)
                //    // client.Connect("172.16.18.8", 22824);
                //    client.Connect("192.168.254.63", 22824);
                //byte[] outStream = System.Text.Encoding.ASCII.GetBytes(jsonObject+"\n");
                //byteCount += System.Text.ASCIIEncoding.ASCII.GetByteCount(jsonObject);
                //Logg.logger.Debug(byteCount);
                //client.Send(outStream);
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
            }

        }

        public static Queue<Globals.Rollback> CloneRollbackQueue(Queue<Globals.Rollback> ToQueue,
            Queue<Globals.Rollback> FromQueue)
        {
            var count = FromQueue.Count;
            for (int i = 0; i < count; i++)
            {
                ToQueue.Enqueue(FromQueue.Dequeue());
            }
            return ToQueue;
        }

        public static void pingNotipier()
        {
            while (true)
            {
                try
                {
                    byte[] outStream = Encoding.ASCII.GetBytes("ping\n");
                    client.Send(outStream);
                    Thread.Sleep(5000);
                    Logg.logger.Fatal("=====================================================================================================");
                }
                catch (Exception)
                {

                }

            }
        }
        public Globals.Rollback SetRollback(long RowId, Globals.Tables Table, Globals.TransactionTypes Transaction)
        {
            var rollbackObject = new Globals.Rollback();
            try
            {
                rollbackObject.RowId = RowId;
                rollbackObject.TableId = (int)Table;
                rollbackObject.TransactionType = (int)Transaction;
            }
            catch (Exception ex)
            {
                Logg.logger.Fatal(ex.Message);
                return null;
            }
            return rollbackObject;
        }
    }
}
