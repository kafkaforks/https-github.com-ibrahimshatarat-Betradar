﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Betradar.Classes
{
    public class test:Core
    {
        public string one { get; set; }
        public Text two { get; set; }

        public test()
        {
            QueueRuntimeCounter();
        }

        public void QueueRuntimeCounter()
        {
            var counter = 0;
            while (true)
            {

              

                Thread.Sleep(100);
            }

        }

    }
}
