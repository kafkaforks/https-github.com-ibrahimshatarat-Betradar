﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Betradar.Classes
{
    class TaskHandler<T> : Core
    {
        public TaskHandler()
        {
        }
       
    }
}
